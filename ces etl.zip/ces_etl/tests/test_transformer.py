# ============================================================
# CES Savings ETL - Transformer Tests
# Run with: pytest tests/test_transformer.py -v
# ============================================================

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from datetime import date
from etl.transformer import DataTransformer
from etl.extractor import clean_header


# Sample column mapping for tests
SAMPLE_MAPPING = [
    {"STG_COLUMN_NAME": "VENDOR_SUBPROGRAM_KEY", "FACT_COLUMN_NAME": "VENDOR_SUBPROGRAM_KEY", "DATA_TYPE": "VARCHAR2"},
    {"STG_COLUMN_NAME": "TOTAL_INVEST_COST",     "FACT_COLUMN_NAME": "TOTAL_INVEST_COST",     "DATA_TYPE": "NUMBER_2"},
    {"STG_COLUMN_NAME": "GROSS_SITE_ELEC_ANNUAL_KWH", "FACT_COLUMN_NAME": "GROSS_SITE_ELEC_ANNUAL_KWH", "DATA_TYPE": "NUMBER_4"},
    {"STG_COLUMN_NAME": "PARTICIPANTS_TOTAL",    "FACT_COLUMN_NAME": "PARTICIPANTS_TOTAL",    "DATA_TYPE": "NUMBER_INT"},
]


# ============================================================
# clean_header tests
# ============================================================
class TestCleanHeader:

    def test_basic_spaces(self):
        assert clean_header("Annual Electric Savings kWh") == "ANNUAL_ELECTRIC_SAVINGS_KWH"

    def test_special_characters_removed(self):
        assert clean_header("Investment - Rebate") == "INVESTMENT_REBATE"

    def test_slash_removed(self):
        assert clean_header("Therms/day") == "THERMSDAY"

    def test_line_breaks(self):
        assert clean_header("Net Realized\nSite Annual") == "NET_REALIZED_SITE_ANNUAL"

    def test_none_returns_empty(self):
        assert clean_header(None) == ""

    def test_empty_string(self):
        assert clean_header("") == ""

    def test_unnamed_column(self):
        assert clean_header("Unnamed: 5") == ""

    def test_multiple_spaces(self):
        assert clean_header("Res LMI  or   OBC") == "RES_LMI_OR_OBC"

    def test_parentheses(self):
        assert clean_header("OBC Only (All Projects)") == "OBC_ONLY_ALL_PROJECTS"


# ============================================================
# DataTransformer tests
# ============================================================
class TestDataTransformer:

    def setup_method(self):
        self.transformer = DataTransformer(SAMPLE_MAPPING)
        self.file_info = {
            "period_sk":        20260401,
            "data_date":        date(2026, 4, 1),
            "file_name":        "ICF_Residential_2026_04.xlsx",
            "vendor_key":       "ICF_Residential",
            "reporting_period": "Apr 2026"
        }

    def test_comma_number_cast(self):
        df = pd.DataFrame([{"TOTAL_INVEST_COST": "1,234.56"}])
        result = self.transformer.transform(df, self.file_info, batch_id=1)
        assert result["TOTAL_INVEST_COST"].iloc[0] == 1234.56

    def test_null_preserved_not_zero(self):
        # Critical business rule: NULL != 0
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": ""}])
        result = self.transformer.transform(df, self.file_info, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None

    def test_zero_stays_zero(self):
        # Zero is a valid reported value, not NULL
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": "0"}])
        result = self.transformer.transform(df, self.file_info, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] == 0

    def test_na_string_becomes_null(self):
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": "N/A"}])
        result = self.transformer.transform(df, self.file_info, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None

    def test_integer_rounding(self):
        df = pd.DataFrame([{"PARTICIPANTS_TOTAL": "120.7"}])
        result = self.transformer.transform(df, self.file_info, batch_id=1)
        assert result["PARTICIPANTS_TOTAL"].iloc[0] == 121

    def test_metadata_added(self):
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "ICF_001"}])
        result = self.transformer.transform(df, self.file_info, batch_id=42)
        assert result["PERIOD_SK"].iloc[0] == 20260401
        assert result["DATA_DATE"].iloc[0] == date(2026, 4, 1)
        assert result["BATCH_ID"].iloc[0] == 42
        assert result["SOURCE_FILE_NAME"].iloc[0] == "ICF_Residential_2026_04.xlsx"

    def test_text_whitespace_stripped(self):
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "  ICF_001  "}])
        result = self.transformer.transform(df, self.file_info, batch_id=1)
        assert result["VENDOR_SUBPROGRAM_KEY"].iloc[0] == "ICF_001"

    def test_currency_symbol_stripped(self):
        df = pd.DataFrame([{"TOTAL_INVEST_COST": "$5,000.00"}])
        result = self.transformer.transform(df, self.file_info, batch_id=1)
        assert result["TOTAL_INVEST_COST"].iloc[0] == 5000.00


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
