# ============================================================
# CES Savings ETL - Database Utility
# Oracle 21c connectivity using oracledb
# Connection pooling for batch performance
# ============================================================

import oracledb
import yaml
import logging
from pathlib import Path
from contextlib import contextmanager

logger = logging.getLogger(__name__)


def load_config() -> dict:
    """Load database configuration from pipeline_config.yaml"""
    config_path = Path(__file__).parent.parent / "config" / "pipeline_config.yaml"
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


class DatabaseManager:
    """
    Manages Oracle database connections and connection pool.
    Use as context manager for automatic connection cleanup.
    """

    _pool = None

    def __init__(self):
        self.config = load_config()["database"]

    def _get_pool(self):
        """Create connection pool if not exists. Reuse if already created."""
        if DatabaseManager._pool is None:
            logger.info("Creating Oracle connection pool")
            DatabaseManager._pool = oracledb.create_pool(
                user=self.config["user"],
                password=self.config["password"],
                dsn=f"{self.config['host']}:{self.config['port']}/{self.config['service']}",
                min=self.config.get("pool_min", 1),
                max=self.config.get("pool_max", 5),
                increment=self.config.get("pool_increment", 1),
            )
            logger.info("Oracle connection pool created successfully")
        return DatabaseManager._pool

    @contextmanager
    def get_connection(self):
        """
        Context manager for database connections.
        Automatically returns connection to pool on exit.

        Usage:
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(...)
        """
        pool = self._get_pool()
        conn = pool.acquire()
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Database error, rolling back: {e}")
            raise
        finally:
            pool.release(conn)

    @contextmanager
    def get_cursor(self):
        """
        Context manager for cursors.
        Automatically commits/rollbacks and closes cursor.

        Usage:
            with db.get_cursor() as cursor:
                cursor.execute(...)
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            try:
                yield cursor
            finally:
                cursor.close()

    def execute(self, sql: str, params: dict = None) -> None:
        """Execute a single SQL statement"""
        with self.get_cursor() as cursor:
            cursor.execute(sql, params or {})

    def execute_many(self, sql: str, data: list, batch_size: int = 1000) -> int:
        """
        Execute bulk insert/update with batching.
        Returns total rows processed.

        Args:
            sql: SQL with :param_name style binds
            data: List of dicts with parameter values
            batch_size: Number of rows per batch
        """
        total_rows = 0
        with self.get_connection() as conn:
            cursor = conn.cursor()
            try:
                # Process in batches for performance
                for i in range(0, len(data), batch_size):
                    batch = data[i:i + batch_size]
                    cursor.executemany(sql, batch)
                    total_rows += len(batch)
                    logger.debug(f"Inserted batch {i//batch_size + 1}: {len(batch)} rows")
            finally:
                cursor.close()
        return total_rows

    def fetch_all(self, sql: str, params: dict = None) -> list:
        """Execute SELECT and return all rows as list of dicts"""
        with self.get_cursor() as cursor:
            cursor.execute(sql, params or {})
            columns = [col[0] for col in cursor.description]
            rows = cursor.fetchall()
            return [dict(zip(columns, row)) for row in rows]

    def fetch_one(self, sql: str, params: dict = None) -> dict:
        """Execute SELECT and return single row as dict"""
        with self.get_cursor() as cursor:
            cursor.execute(sql, params or {})
            columns = [col[0] for col in cursor.description]
            row = cursor.fetchone()
            return dict(zip(columns, row)) if row else None

    def load_column_mapping(self, sheet_name: str) -> list:
        """
        Load column mapping from CES_SAVINGS_COLUMN_MAP table.
        Returns list of active mappings for the given sheet.
        """
        sql = """
            SELECT
                EXCEL_ROW1_HEADER,
                EXCEL_ROW2_HEADER,
                EXCEL_ROW3_HEADER,
                EXCEL_COL_POSITION,
                STG_TABLE_NAME,
                STG_COLUMN_NAME,
                FACT_TABLE_NAME,
                FACT_COLUMN_NAME,
                DATA_TYPE,
                IS_DIMENSION,
                IS_REQUIRED,
                IS_STOP_COLUMN
            FROM CES_SAVINGS_COLUMN_MAP
            WHERE SHEET_NAME = :sheet_name
            AND   IS_ACTIVE  = 'Y'
            ORDER BY MAP_ID
        """
        return self.fetch_all(sql, {"sheet_name": sheet_name})

    def truncate_stg_table(self, table_name: str) -> None:
        """Truncate staging table before each load"""
        logger.info(f"Truncating staging table: {table_name}")
        self.execute(f"TRUNCATE TABLE {table_name}")

    def close_pool(self) -> None:
        """Close connection pool. Call at end of pipeline run."""
        if DatabaseManager._pool:
            DatabaseManager._pool.close()
            DatabaseManager._pool = None
            logger.info("Oracle connection pool closed")


# Module level singleton
db = DatabaseManager()
