# ============================================================
# CES Savings ETL - Validator
# Validates extracted data before loading to FACT
# Logs row-level errors to ETL_ROW_LOG
# ============================================================

import logging
import pandas as pd
from typing import Optional
from dataclasses import dataclass, field

logger = logging.getLogger("ces_etl.validator")


@dataclass
class ValidationResult:
    """Holds outcome of validating one file's data."""
    passed: bool = True
    total_rows: int = 0
    valid_rows: int = 0
    failed_rows: int = 0
    errors: list = field(default_factory=list)   # list of error dicts
    error_summary: str = ""


class DataValidator:
    """
    Validates a DataFrame of extracted rows against the column mapping.

    Checks performed:
    - Required columns are present and non-null (VENDOR_SUBPROGRAM_KEY, period)
    - Numeric columns can be cast to numbers (commas / blanks tolerated)
    - NULL preserved (NULL != 0 - kept distinct per business rule)

    Errors are collected (not raised) so the whole file can be assessed,
    then logged row-by-row to ETL_ROW_LOG by the caller.
    """

    def __init__(self, column_mapping: list, max_errors: int = 100):
        self.column_mapping = column_mapping
        self.max_errors = max_errors

        # Pre-compute column type maps
        self.required_cols = [
            m["STG_COLUMN_NAME"] for m in column_mapping if m["IS_REQUIRED"] == "Y"
        ]
        self.numeric_cols = {
            m["STG_COLUMN_NAME"]: m["DATA_TYPE"]
            for m in column_mapping
            if m["DATA_TYPE"] in ("NUMBER_2", "NUMBER_4", "NUMBER_INT")
        }

    def validate(self, df: pd.DataFrame) -> ValidationResult:
        """
        Validate the DataFrame. Returns ValidationResult.
        Does not modify df; transformation happens in transformer.
        """
        result = ValidationResult(total_rows=len(df))

        if df.empty:
            result.passed = False
            result.error_summary = "No data rows extracted"
            logger.warning("Validation: empty DataFrame")
            return result

        # Check required columns exist as DataFrame columns
        missing_required = [c for c in self.required_cols if c not in df.columns]
        if missing_required:
            result.passed = False
            result.error_summary = f"Missing required columns: {missing_required}"
            logger.error(result.error_summary)
            return result

        # Row-by-row validation
        failed_row_indices = set()

        for idx, row in df.iterrows():
            row_has_error = False

            # Required column null check
            for col in self.required_cols:
                value = row.get(col)
                if value is None or str(value).strip() == "":
                    result.errors.append({
                        "row_number":   idx,
                        "column_name":  col,
                        "source_value": value,
                        "error_type":   "NULL_VALUE",
                        "error_message": f"Required column {col} is null or blank",
                        "expected_format": "non-null"
                    })
                    row_has_error = True

            # Numeric column type check
            for col, dtype in self.numeric_cols.items():
                if col not in df.columns:
                    continue
                value = row.get(col)
                if value is None or str(value).strip() == "":
                    continue  # NULL is allowed - preserved as-is
                if not self._is_castable_number(value):
                    result.errors.append({
                        "row_number":   idx,
                        "column_name":  col,
                        "source_value": value,
                        "error_type":   "TYPE_MISMATCH",
                        "error_message": f"Cannot cast '{value}' to number",
                        "expected_format": dtype
                    })
                    row_has_error = True

            if row_has_error:
                failed_row_indices.add(idx)

            # Stop collecting if too many errors
            if len(result.errors) >= self.max_errors:
                logger.warning(
                    f"Validation hit max_errors limit ({self.max_errors}), "
                    f"stopping error collection"
                )
                break

        result.failed_rows = len(failed_row_indices)
        result.valid_rows = result.total_rows - result.failed_rows

        # Determine pass/fail
        # File fails entirely if error count exceeds max threshold
        if len(result.errors) >= self.max_errors:
            result.passed = False
            result.error_summary = (
                f"Too many errors ({len(result.errors)}+), file quarantined"
            )
        elif result.failed_rows > 0:
            # Partial - some rows bad but file can still load good rows
            result.passed = True
            result.error_summary = (
                f"{result.failed_rows} rows have errors, "
                f"{result.valid_rows} rows valid"
            )
        else:
            result.passed = True
            result.error_summary = "All rows valid"

        logger.info(
            f"Validation: {result.valid_rows}/{result.total_rows} valid, "
            f"{result.failed_rows} failed, {len(result.errors)} errors"
        )
        return result

    @staticmethod
    def _is_castable_number(value) -> bool:
        """
        Check if a value can be cast to a number.
        Tolerates commas, currency symbols, whitespace.
        """
        if isinstance(value, (int, float)):
            return True
        try:
            cleaned = str(value).replace(",", "").replace("$", "").strip()
            if cleaned == "" or cleaned.upper() in ("N/A", "NA", "NULL", "-"):
                return False
            float(cleaned)
            return True
        except (ValueError, TypeError):
            return False
