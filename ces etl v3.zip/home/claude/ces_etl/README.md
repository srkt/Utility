# CES Savings ETL Pipeline

Monthly ETL pipeline that loads ~150 vendor Excel files into an Oracle 21c
data warehouse for Power BI reporting.

## Overview

```
Vendor Excel files (shared drive / SharePoint)
        |
   Jenkins (monthly trigger)
        |
   Python ETL
   - Extract (3-row header parsing)
   - Validate (row-level error logging)
   - Transform (type cast, NULL preserved)
   - Load (STG -> FACT with versioning)
        |
   Oracle 21c warehouse
        |
   Power BI (reads VW_* views only)
```

## Project Structure

```
ces_etl/
├── requirements.txt          Python dependencies
├── main.py                   Pipeline orchestrator (entry point)
├── Jenkinsfile               Jenkins pipeline definition
├── config/
│   ├── pipeline_config.yaml  All settings (DB, paths, behavior)
│   └── column_mapping.yaml   Excel->Oracle column map (reference copy)
├── etl/
│   ├── extractor.py          Reads Excel 3-row headers
│   ├── validator.py          Validates rows, collects errors
│   ├── transformer.py        Type casting, NULL preservation
│   └── loader.py             STG + FACT load, resubmission logic
├── utils/
│   ├── db.py                 Oracle connection pool
│   ├── logger.py             Console/file + audit table logging
│   ├── file_manager.py       Shared drive file operations
│   ├── sharepoint.py         SharePoint download (alternative source)
│   └── notifier.py           Email notifications
├── sql/
│   └── ces_savings_column_map.sql   Column mapping table + seed data
└── tests/
    └── test_transformer.py   Unit tests
```

## Setup

### 1. Database
Run the DDL scripts in order:
```bash
# Main warehouse tables (run once)
sqlplus user/pass @CES_SAVINGS_DDL_V2.sql
sqlplus user/pass @CES_SAVINGS_ALTER_V3.sql

# Column mapping table + seed data
sqlplus user/pass @sql/ces_savings_column_map.sql
```

### 2. Python Environment
```bash
python3.10 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. Configuration
Edit `config/pipeline_config.yaml`:
- Database connection (use env vars for password in production)
- File source type: `shared_drive` or `sharepoint`
- File paths
- Notification settings

## Running

### Manual run
```bash
python main.py
```

### Process only one sheet
```bash
python main.py --sheets savings_results
```

### With Jenkins context
```bash
python main.py --jenkins-job "CES_ETL" --build-number "42"
```

## Key Design Decisions

### NULL vs Zero
NULL and 0 are kept **distinct**. NULL means vendor did not report;
0 means vendor reported zero. The transformer never converts NULL to 0.

### PERIOD_SK format
`YYYYMMDD` with day always `01` for monthly grain (e.g. `20260401` = April 2026).
Derived from the vendor filename pattern `*_YYYY_MM.xlsx`.

### Column Mapping
`CES_SAVINGS_COLUMN_MAP` table is the single source of truth. It maps the
Excel 3-row header (row1=energy type, row2=calc method, row3=metric name)
to Oracle column names. To add/change columns, update this table - no code
changes needed.

### Stop Condition
Data loading stops when `VENDOR_SUBPROGRAM_KEY` is null/blank. This excludes
summary rows and trailing junk automatically.

### Resubmission Handling
If a vendor + period already exists in FACT, the old row is marked
`IS_CURRENT_VERSION = 'N'` and a new row is inserted with incremented
`VERSION_NUMBER`. Nothing is ever deleted (full audit trail).

## Audit Trail

Three levels of logging in Oracle:
- `CES_SAVINGS_ETL_BATCH_LOG` - one row per pipeline run
- `CES_SAVINGS_ETL_FILE_LOG`  - one row per vendor file
- `CES_SAVINGS_ETL_ROW_LOG`   - one row per failed cell

Query pipeline health:
```sql
SELECT * FROM CES_SAVINGS_VW_PIPELINE_HEALTH;
```

## Switching to SharePoint

In `pipeline_config.yaml`:
```yaml
file_source:
  type: "sharepoint"   # change from shared_drive
```
Configure the `sharepoint` section with site URL and credentials.
`utils/sharepoint.py` downloads files to a local path, then the
regular `file_manager.py` takes over.

## Testing

```bash
pytest tests/ -v
```

## Maintenance Guide

### Adding a new column
1. Add column to FACT/STG tables (ALTER TABLE)
2. Insert row into `CES_SAVINGS_COLUMN_MAP`
3. No Python code change needed

### Template version changed
1. Check if header row shifted -> update `header_row` in config
2. Check if column names changed -> update `CES_SAVINGS_COLUMN_MAP`
3. Update `expected_template_version` in config

### Common issues
| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| File quarantined | Validation errors | Check ETL_ROW_LOG for details |
| Column not loading | Header mismatch | Check CES_SAVINGS_COLUMN_MAP |
| Wrong period | Filename pattern | Check filename ends `_YYYY_MM.xlsx` |
| Mapping not found | Sheet name mismatch | Check sheet_name in config |
