# ============================================================
# CES Savings ETL - Validator Tests
# Tests for required columns, type checks,
# NULL handling, max errors threshold
# Run with: pytest tests/test_validator.py -v
# ============================================================

import sys
import pytest
import pandas as pd
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from etl.validator import DataValidator

# ============================================================
# SAMPLE COLUMN MAPPING
# ============================================================
SAMPLE_MAPPING = [
    {
        "STG_COLUMN_NAME": "VENDOR_SUBPROGRAM_KEY",
        "DATA_TYPE":       "VARCHAR2",
        "IS_REQUIRED":     "Y",
        "IS_STOP_COLUMN":  "Y"
    },
    {
        "STG_COLUMN_NAME": "REPORTING_PERIOD",
        "DATA_TYPE":       "VARCHAR2",
        "IS_REQUIRED":     "Y",
        "IS_STOP_COLUMN":  "N"
    },
    {
        "STG_COLUMN_NAME": "SECTOR",
        "DATA_TYPE":       "VARCHAR2",
        "IS_REQUIRED":     "N",
        "IS_STOP_COLUMN":  "N"
    },
    {
        "STG_COLUMN_NAME": "INVEST_COST_REBATE",
        "DATA_TYPE":       "NUMBER_2",
        "IS_REQUIRED":     "N",
        "IS_STOP_COLUMN":  "N"
    },
    {
        "STG_COLUMN_NAME": "INVEST_COST_OBR",
        "DATA_TYPE":       "NUMBER_2",
        "IS_REQUIRED":     "N",
        "IS_STOP_COLUMN":  "N"
    },
    {
        "STG_COLUMN_NAME": "GROSS_SITE_ELEC_ANNUAL_KWH",
        "DATA_TYPE":       "NUMBER_4",
        "IS_REQUIRED":     "N",
        "IS_STOP_COLUMN":  "N"
    },
    {
        "STG_COLUMN_NAME": "PARTICIPANTS_TOTAL",
        "DATA_TYPE":       "NUMBER_INT",
        "IS_REQUIRED":     "N",
        "IS_STOP_COLUMN":  "N"
    }
]


def make_valid_df(n=3) -> pd.DataFrame:
    """Return a valid DataFrame with n rows"""
    rows = []
    for i in range(n):
        rows.append({
            "VENDOR_SUBPROGRAM_KEY":    f"ICF_00{i+1}",
            "REPORTING_PERIOD":         "Apr 2026",
            "SECTOR":                   "Residential",
            "INVEST_COST_REBATE":       "1000.00",
            "INVEST_COST_OBR":          "500.00",
            "GROSS_SITE_ELEC_ANNUAL_KWH": "15000.0",
            "PARTICIPANTS_TOTAL":       "120"
        })
    return pd.DataFrame(rows)


# ============================================================
# SECTION 1: Mock tests - required column validation
# ============================================================
class TestRequiredColumnsMock:
    """Required column validation - no file I/O"""

    def setup_method(self):
        self.validator = DataValidator(SAMPLE_MAPPING)

    def test_valid_data_passes(self):
        df = make_valid_df()
        result = self.validator.validate(df)
        assert result.passed is True
        assert result.failed_rows == 0
        assert len(result.errors) == 0

    def test_null_required_column_fails(self):
        df = make_valid_df(1)
        df.at[0, "VENDOR_SUBPROGRAM_KEY"] = None
        result = self.validator.validate(df)
        assert len(result.errors) > 0
        error_cols = [e["column_name"] for e in result.errors]
        assert "VENDOR_SUBPROGRAM_KEY" in error_cols

    def test_blank_required_column_fails(self):
        df = make_valid_df(1)
        df.at[0, "VENDOR_SUBPROGRAM_KEY"] = ""
        result = self.validator.validate(df)
        error_cols = [e["column_name"] for e in result.errors]
        assert "VENDOR_SUBPROGRAM_KEY" in error_cols

    def test_null_optional_column_passes(self):
        """NULL in optional column should not cause error"""
        df = make_valid_df(1)
        df.at[0, "SECTOR"] = None
        result = self.validator.validate(df)
        error_cols = [e["column_name"] for e in result.errors]
        assert "SECTOR" not in error_cols

    def test_both_required_columns_null_catches_both(self):
        df = make_valid_df(1)
        df.at[0, "VENDOR_SUBPROGRAM_KEY"] = None
        df.at[0, "REPORTING_PERIOD"] = None
        result = self.validator.validate(df)
        error_cols = [e["column_name"] for e in result.errors]
        assert "VENDOR_SUBPROGRAM_KEY" in error_cols
        assert "REPORTING_PERIOD" in error_cols

    def test_missing_required_column_from_df(self):
        """If required column doesn't exist in DataFrame at all"""
        df = make_valid_df(1)
        df = df.drop(columns=["VENDOR_SUBPROGRAM_KEY"])
        result = self.validator.validate(df)
        assert result.passed is False

    def test_empty_dataframe_fails(self):
        df = pd.DataFrame()
        result = self.validator.validate(df)
        assert result.passed is False
        assert result.total_rows == 0

    def test_error_type_null_value(self):
        df = make_valid_df(1)
        df.at[0, "VENDOR_SUBPROGRAM_KEY"] = None
        result = self.validator.validate(df)
        error_types = [e["error_type"] for e in result.errors]
        assert "NULL_VALUE" in error_types


# ============================================================
# SECTION 2: Mock tests - numeric type validation
# ============================================================
class TestNumericValidationMock:
    """Numeric type validation - no file I/O"""

    def setup_method(self):
        self.validator = DataValidator(SAMPLE_MAPPING)

    def test_valid_number_string_passes(self):
        df = make_valid_df(1)
        df.at[0, "INVEST_COST_REBATE"] = "1234.56"
        result = self.validator.validate(df)
        cost_errors = [
            e for e in result.errors
            if e["column_name"] == "INVEST_COST_REBATE"
        ]
        assert len(cost_errors) == 0

    def test_comma_number_passes(self):
        """Numbers with commas are valid e.g. 1,234.56"""
        df = make_valid_df(1)
        df.at[0, "INVEST_COST_REBATE"] = "1,234.56"
        result = self.validator.validate(df)
        cost_errors = [
            e for e in result.errors
            if e["column_name"] == "INVEST_COST_REBATE"
        ]
        assert len(cost_errors) == 0

    def test_integer_passes_as_number(self):
        df = make_valid_df(1)
        df.at[0, "INVEST_COST_REBATE"] = "5000"
        result = self.validator.validate(df)
        cost_errors = [
            e for e in result.errors
            if e["column_name"] == "INVEST_COST_REBATE"
        ]
        assert len(cost_errors) == 0

    def test_text_in_number_column_fails(self):
        df = make_valid_df(1)
        df.at[0, "INVEST_COST_REBATE"] = "INVALID"
        result = self.validator.validate(df)
        cost_errors = [
            e for e in result.errors
            if e["column_name"] == "INVEST_COST_REBATE"
        ]
        assert len(cost_errors) > 0
        assert cost_errors[0]["error_type"] == "TYPE_MISMATCH"

    def test_na_string_treated_as_null(self):
        """N/A string in numeric column treated as NULL not error"""
        df = make_valid_df(1)
        df.at[0, "INVEST_COST_REBATE"] = "N/A"
        result = self.validator.validate(df)
        cost_errors = [
            e for e in result.errors
            if e["column_name"] == "INVEST_COST_REBATE"
        ]
        # N/A treated as NULL which is allowed
        assert len(cost_errors) == 0

    def test_null_in_numeric_column_passes(self):
        """NULL in numeric column is valid - preserved as NULL"""
        df = make_valid_df(1)
        df.at[0, "GROSS_SITE_ELEC_ANNUAL_KWH"] = None
        result = self.validator.validate(df)
        elec_errors = [
            e for e in result.errors
            if e["column_name"] == "GROSS_SITE_ELEC_ANNUAL_KWH"
        ]
        assert len(elec_errors) == 0

    def test_zero_passes_in_numeric_column(self):
        """Zero is a valid reported value"""
        df = make_valid_df(1)
        df.at[0, "GROSS_SITE_ELEC_ANNUAL_KWH"] = "0"
        result = self.validator.validate(df)
        elec_errors = [
            e for e in result.errors
            if e["column_name"] == "GROSS_SITE_ELEC_ANNUAL_KWH"
        ]
        assert len(elec_errors) == 0

    def test_negative_number_passes(self):
        """Negative values are valid (e.g. Negative IEs)"""
        df = make_valid_df(1)
        df.at[0, "GROSS_SITE_ELEC_ANNUAL_KWH"] = "-1500.00"
        result = self.validator.validate(df)
        elec_errors = [
            e for e in result.errors
            if e["column_name"] == "GROSS_SITE_ELEC_ANNUAL_KWH"
        ]
        assert len(elec_errors) == 0

    def test_source_value_preserved_in_error(self):
        """Error record should contain the original bad value"""
        df = make_valid_df(1)
        df.at[0, "INVEST_COST_REBATE"] = "BAD_VALUE"
        result = self.validator.validate(df)
        cost_errors = [
            e for e in result.errors
            if e["column_name"] == "INVEST_COST_REBATE"
        ]
        assert cost_errors[0]["source_value"] == "BAD_VALUE"


# ============================================================
# SECTION 3: Mock tests - max errors threshold
# ============================================================
class TestMaxErrorsMock:
    """Max errors threshold - no file I/O"""

    def test_below_max_errors_passes(self):
        """File with few errors still passes (partial load)"""
        validator = DataValidator(SAMPLE_MAPPING, max_errors=10)
        df = make_valid_df(5)
        # Make 2 rows bad
        df.at[0, "INVEST_COST_REBATE"] = "BAD"
        df.at[1, "INVEST_COST_REBATE"] = "ALSO_BAD"
        result = validator.validate(df)
        assert result.passed is True  # Under threshold - partial ok
        assert result.failed_rows == 2
        assert result.valid_rows == 3

    def test_exceeds_max_errors_fails(self):
        """File with too many errors should fail entirely"""
        validator = DataValidator(SAMPLE_MAPPING, max_errors=3)
        df = make_valid_df(10)
        # Make many rows bad
        for i in range(10):
            df.at[i, "INVEST_COST_REBATE"] = "BAD"
            df.at[i, "INVEST_COST_OBR"] = "ALSO_BAD"
        result = validator.validate(df)
        assert result.passed is False
        assert "Too many errors" in result.error_summary

    def test_error_collection_stops_at_max(self):
        """Should stop collecting after max_errors"""
        validator = DataValidator(SAMPLE_MAPPING, max_errors=5)
        df = make_valid_df(20)
        for i in range(20):
            df.at[i, "INVEST_COST_REBATE"] = "BAD"
        result = validator.validate(df)
        assert len(result.errors) <= 5 + 1  # Allow slight overshoot


# ============================================================
# SECTION 4: Mock tests - row counting
# ============================================================
class TestRowCountsMock:
    """Row count tracking - no file I/O"""

    def setup_method(self):
        self.validator = DataValidator(SAMPLE_MAPPING)

    def test_total_rows_counted(self):
        df = make_valid_df(5)
        result = self.validator.validate(df)
        assert result.total_rows == 5

    def test_valid_rows_counted(self):
        df = make_valid_df(5)
        df.at[0, "INVEST_COST_REBATE"] = "BAD"
        result = self.validator.validate(df)
        assert result.failed_rows == 1
        assert result.valid_rows == 4

    def test_all_rows_valid(self):
        df = make_valid_df(10)
        result = self.validator.validate(df)
        assert result.valid_rows == 10
        assert result.failed_rows == 0

    def test_all_rows_failed(self):
        df = make_valid_df(3)
        for i in range(3):
            df.at[i, "VENDOR_SUBPROGRAM_KEY"] = None
        result = self.validator.validate(df)
        assert result.failed_rows == 3


# ============================================================
# SECTION 5: Real file tests
# ============================================================
class TestValidatorReal:
    """Integration tests with real DataFrames from extractor"""

    def setup_method(self):
        self.validator = DataValidator(SAMPLE_MAPPING)

    def _make_df(self, rows: list) -> pd.DataFrame:
        cols = [
            "VENDOR_SUBPROGRAM_KEY", "REPORTING_PERIOD", "SECTOR",
            "INVEST_COST_REBATE", "INVEST_COST_OBR",
            "GROSS_SITE_ELEC_ANNUAL_KWH", "PARTICIPANTS_TOTAL"
        ]
        return pd.DataFrame(rows, columns=cols)

    def test_typical_vendor_file_passes(self):
        """Simulate a typical clean vendor file"""
        df = self._make_df([
            ["ICF_RES_001", "Apr 2026", "Residential",
             "50000.00", "25000.00", "125000.0", "450"],
            ["ICF_RES_002", "Apr 2026", "Residential",
             "60000.00", "30000.00", "150000.0", "520"],
            ["ICF_COM_001", "Apr 2026", "Commercial",
             "75000.00", "35000.00", "200000.0", "180"]
        ])
        result = self.validator.validate(df)
        assert result.passed is True
        assert result.failed_rows == 0

    def test_vendor_file_with_nulls_in_optional(self):
        """Vendor may not report all optional fields"""
        df = self._make_df([
            ["ICF_RES_001", "Apr 2026", None,     # sector optional
             "50000.00", None, "125000.0", "450"],  # OBR optional
        ])
        result = self.validator.validate(df)
        assert result.passed is True
        assert result.failed_rows == 0

    def test_vendor_file_with_comma_costs(self):
        """Costs submitted with commas should pass validation"""
        df = self._make_df([
            ["ICF_RES_001", "Apr 2026", "Residential",
             "1,234,567.89", "500,000.00", "125,000.0", "450"]
        ])
        result = self.validator.validate(df)
        assert result.passed is True

    def test_vendor_file_missing_vendor_key(self):
        """Missing vendor key is critical error"""
        df = self._make_df([
            [None, "Apr 2026", "Residential",
             "50000.00", "25000.00", "125000.0", "450"]
        ])
        result = self.validator.validate(df)
        error_cols = [e["column_name"] for e in result.errors]
        assert "VENDOR_SUBPROGRAM_KEY" in error_cols

    def test_mixed_valid_invalid_rows(self):
        """Some rows valid some invalid"""
        df = self._make_df([
            ["ICF_001", "Apr 2026", "Residential",
             "50000.00", "25000.00", "125000.0", "450"],   # valid
            ["ICF_002", "Apr 2026", "Residential",
             "NOT_A_NUMBER", "25000.00", "125000.0", "450"],  # bad cost
            ["ICF_003", "Apr 2026", "Residential",
             "70000.00", "35000.00", "150000.0", "380"]    # valid
        ])
        result = self.validator.validate(df)
        assert result.passed is True  # Under max errors threshold
        assert result.failed_rows == 1
        assert result.valid_rows == 2

    def test_error_summary_populated(self):
        """Error summary should describe what went wrong"""
        df = self._make_df([
            ["ICF_001", "Apr 2026", "Residential",
             "BAD", "25000.00", "125000.0", "450"]
        ])
        result = self.validator.validate(df)
        assert result.error_summary != ""
        assert len(result.error_summary) > 0


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
