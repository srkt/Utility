# ============================================================
# CES Savings ETL - Transformer Tests (Updated)
# Tests for type casting, NULL preservation,
# metadata injection, text cleaning
# Run with: pytest tests/test_transformer.py -v
# ============================================================

import sys
import pytest
import pandas as pd
from pathlib import Path
from datetime import date

sys.path.insert(0, str(Path(__file__).parent.parent))

from etl.transformer import DataTransformer

SAMPLE_MAPPING = [
    {"STG_COLUMN_NAME": "VENDOR_SUBPROGRAM_KEY",
     "FACT_COLUMN_NAME": "VENDOR_SUBPROGRAM_KEY", "DATA_TYPE": "VARCHAR2"},
    {"STG_COLUMN_NAME": "REPORTING_PERIOD",
     "FACT_COLUMN_NAME": "REPORTING_PERIOD", "DATA_TYPE": "VARCHAR2"},
    {"STG_COLUMN_NAME": "SECTOR",
     "FACT_COLUMN_NAME": "SECTOR", "DATA_TYPE": "VARCHAR2"},
    {"STG_COLUMN_NAME": "INVEST_COST_REBATE",
     "FACT_COLUMN_NAME": "INVEST_COST_REBATE", "DATA_TYPE": "NUMBER_2"},
    {"STG_COLUMN_NAME": "INVEST_COST_OBR",
     "FACT_COLUMN_NAME": "INVEST_COST_OBR", "DATA_TYPE": "NUMBER_2"},
    {"STG_COLUMN_NAME": "TOTAL_INVEST_COST",
     "FACT_COLUMN_NAME": "TOTAL_INVEST_COST", "DATA_TYPE": "NUMBER_2"},
    {"STG_COLUMN_NAME": "GROSS_SITE_ELEC_ANNUAL_KWH",
     "FACT_COLUMN_NAME": "GROSS_SITE_ELEC_ANNUAL_KWH", "DATA_TYPE": "NUMBER_4"},
    {"STG_COLUMN_NAME": "GROSS_SITE_GAS_ANNUAL_THERMS",
     "FACT_COLUMN_NAME": "GROSS_SITE_GAS_ANNUAL_THERMS", "DATA_TYPE": "NUMBER_4"},
    {"STG_COLUMN_NAME": "PARTICIPANTS_TOTAL",
     "FACT_COLUMN_NAME": "PARTICIPANTS_TOTAL", "DATA_TYPE": "NUMBER_INT"},
    {"STG_COLUMN_NAME": "NET_SRC_ANNUAL_MMBTU",
     "FACT_COLUMN_NAME": "NET_SRC_ANNUAL_MMBTU", "DATA_TYPE": "NUMBER_4"},
]

FILE_INFO = {
    "period_sk":        20260401,
    "data_date":        date(2026, 4, 1),
    "file_name":        "ICF_Residential_2026_04.xlsx",
    "vendor_key":       "ICF_Residential",
    "reporting_period": "Apr 2026"
}


# ============================================================
# SECTION 1: Mock tests - numeric casting
# ============================================================
class TestNumericCastingMock:
    def setup_method(self):
        self.t = DataTransformer(SAMPLE_MAPPING)

    def test_plain_number_cast(self):
        df = pd.DataFrame([{"TOTAL_INVEST_COST": "1234.56"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["TOTAL_INVEST_COST"].iloc[0] == 1234.56

    def test_comma_number_cast(self):
        df = pd.DataFrame([{"TOTAL_INVEST_COST": "1,234,567.89"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["TOTAL_INVEST_COST"].iloc[0] == 1234567.89

    def test_currency_symbol_stripped(self):
        df = pd.DataFrame([{"TOTAL_INVEST_COST": "$5,000.00"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["TOTAL_INVEST_COST"].iloc[0] == 5000.00

    def test_negative_number_cast(self):
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": "-1500.50"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] == -1500.50

    def test_integer_cast(self):
        df = pd.DataFrame([{"PARTICIPANTS_TOTAL": "120"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["PARTICIPANTS_TOTAL"].iloc[0] == 120

    def test_float_rounds_to_int(self):
        df = pd.DataFrame([{"PARTICIPANTS_TOTAL": "120.7"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["PARTICIPANTS_TOTAL"].iloc[0] == 121

    def test_zero_stays_zero(self):
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": "0"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] == 0.0

    def test_integer_input(self):
        df = pd.DataFrame([{"TOTAL_INVEST_COST": 5000}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["TOTAL_INVEST_COST"].iloc[0] == 5000.0

    def test_float_input(self):
        df = pd.DataFrame([{"TOTAL_INVEST_COST": 5000.99}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["TOTAL_INVEST_COST"].iloc[0] == 5000.99


# ============================================================
# SECTION 2: Mock tests - NULL preservation (critical)
# ============================================================
class TestNullPreservationMock:
    def setup_method(self):
        self.t = DataTransformer(SAMPLE_MAPPING)

    def test_none_stays_none(self):
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": None}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None

    def test_empty_string_becomes_none(self):
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": ""}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None

    def test_na_string_becomes_none(self):
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": "N/A"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None

    def test_null_string_becomes_none(self):
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": "NULL"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None

    def test_dash_becomes_none(self):
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": "-"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None

    def test_zero_not_converted_to_none(self):
        """Critical: 0 != NULL"""
        df = pd.DataFrame([{"GROSS_SITE_ELEC_ANNUAL_KWH": "0"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is not None
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] == 0.0

    def test_null_in_cost_column(self):
        df = pd.DataFrame([{"INVEST_COST_REBATE": None}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["INVEST_COST_REBATE"].iloc[0] is None

    def test_null_in_participant_count(self):
        df = pd.DataFrame([{"PARTICIPANTS_TOTAL": None}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["PARTICIPANTS_TOTAL"].iloc[0] is None


# ============================================================
# SECTION 3: Mock tests - metadata injection
# ============================================================
class TestMetadataInjectionMock:
    def setup_method(self):
        self.t = DataTransformer(SAMPLE_MAPPING)

    def test_period_sk_added(self):
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "ICF_001"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["PERIOD_SK"].iloc[0] == 20260401

    def test_data_date_added(self):
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "ICF_001"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["DATA_DATE"].iloc[0] == date(2026, 4, 1)

    def test_source_file_name_added(self):
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "ICF_001"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["SOURCE_FILE_NAME"].iloc[0] == "ICF_Residential_2026_04.xlsx"

    def test_batch_id_added(self):
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "ICF_001"}])
        result = self.t.transform(df, FILE_INFO, batch_id=99)
        assert result["BATCH_ID"].iloc[0] == 99

    def test_period_sk_yyyymmdd_format(self):
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "ICF_001"}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        period_sk = result["PERIOD_SK"].iloc[0]
        assert len(str(period_sk)) == 8
        assert str(period_sk).endswith("01")  # day always 01


# ============================================================
# SECTION 4: Mock tests - text cleaning
# ============================================================
class TestTextCleaningMock:
    def setup_method(self):
        self.t = DataTransformer(SAMPLE_MAPPING)

    def test_whitespace_stripped(self):
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "  ICF_001  "}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["VENDOR_SUBPROGRAM_KEY"].iloc[0] == "ICF_001"

    def test_internal_spaces_preserved(self):
        df = pd.DataFrame([{"SECTOR": "  Residential LMI  "}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["SECTOR"].iloc[0] == "Residential LMI"

    def test_blank_text_becomes_none(self):
        df = pd.DataFrame([{"SECTOR": "   "}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["SECTOR"].iloc[0] is None

    def test_none_text_stays_none(self):
        df = pd.DataFrame([{"SECTOR": None}])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["SECTOR"].iloc[0] is None


# ============================================================
# SECTION 5: Real integration tests
# ============================================================
class TestTransformerReal:
    def setup_method(self):
        self.t = DataTransformer(SAMPLE_MAPPING)

    def _make_df(self, rows) -> pd.DataFrame:
        cols = [m["STG_COLUMN_NAME"] for m in SAMPLE_MAPPING]
        return pd.DataFrame(rows, columns=cols)

    def test_typical_vendor_row(self):
        df = self._make_df([[
            "ICF_RESIDENTIAL_LMI_001", "Apr 2026", "Residential",
            "125,432.50", "62,716.25", "188,148.75",
            "1,250,000.0", "85,000.0", "450", "4,250.5"
        ]])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["VENDOR_SUBPROGRAM_KEY"].iloc[0] == "ICF_RESIDENTIAL_LMI_001"
        assert result["INVEST_COST_REBATE"].iloc[0] == 125432.50
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] == 1250000.0
        assert result["PARTICIPANTS_TOTAL"].iloc[0] == 450

    def test_multiple_rows_transformed(self):
        rows = []
        for i in range(5):
            rows.append([
                f"ICF_00{i+1}", "Apr 2026", "Residential",
                f"{(i+1)*1000}.00", f"{(i+1)*500}.00",
                f"{(i+1)*1500}.00", f"{(i+1)*10000}.0",
                f"{(i+1)*1000}.0", f"{(i+1)*100}", f"{(i+1)*100.5}"
            ])
        df = self._make_df(rows)
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert len(result) == 5
        assert all(result["PERIOD_SK"] == 20260401)
        assert all(result["BATCH_ID"] == 1)

    def test_mixed_null_and_values(self):
        df = self._make_df([[
            "ICF_001", "Apr 2026", None,
            "50000.00", None, "75000.00",
            None, "5000.0", "200", "150.5"
        ]])
        result = self.t.transform(df, FILE_INFO, batch_id=1)
        assert result["SECTOR"].iloc[0] is None
        assert result["INVEST_COST_OBR"].iloc[0] is None
        assert result["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None
        assert result["GROSS_SITE_GAS_ANNUAL_THERMS"].iloc[0] == 5000.0

    def test_different_month_file(self):
        jan_file_info = {
            "period_sk": 20260101, "data_date": date(2026, 1, 1),
            "file_name": "ICF_2026_01.xlsx",
            "vendor_key": "ICF", "reporting_period": "Jan 2026"
        }
        df = pd.DataFrame([{"VENDOR_SUBPROGRAM_KEY": "ICF_001"}])
        result = self.t.transform(df, jan_file_info, batch_id=5)
        assert result["PERIOD_SK"].iloc[0] == 20260101
        assert result["DATA_DATE"].iloc[0] == date(2026, 1, 1)


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
