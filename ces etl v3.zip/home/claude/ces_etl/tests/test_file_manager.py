# ============================================================
# CES Savings ETL - File Manager Tests
# Tests for filename parsing, period_sk extraction,
# archive, quarantine, scan
# Run with: pytest tests/test_file_manager.py -v
# ============================================================

import sys
import pytest
import shutil
from pathlib import Path
from datetime import date
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent))

from utils.file_manager import FileManager


# ============================================================
# FIXTURES
# ============================================================
@pytest.fixture
def tmp_dirs(tmp_path):
    """Create temporary directories for testing"""
    landing    = tmp_path / "landing"
    archive    = tmp_path / "archive"
    quarantine = tmp_path / "quarantine"
    processed  = tmp_path / "processed"
    for d in [landing, archive, quarantine, processed]:
        d.mkdir()
    return {
        "landing":    landing,
        "archive":    archive,
        "quarantine": quarantine,
        "processed":  processed,
        "root":       tmp_path
    }


@pytest.fixture
def file_mgr(tmp_dirs):
    """FileManager with mocked config pointing to tmp dirs"""
    with patch("utils.file_manager.FILE_CONFIG", {
        "landing_path":    str(tmp_dirs["landing"]),
        "archive_path":    str(tmp_dirs["archive"]),
        "quarantine_path": str(tmp_dirs["quarantine"]),
        "processed_path":  str(tmp_dirs["processed"])
    }):
        mgr = FileManager()
        mgr.landing_path    = tmp_dirs["landing"]
        mgr.archive_path    = tmp_dirs["archive"]
        mgr.quarantine_path = tmp_dirs["quarantine"]
        yield mgr, tmp_dirs


def create_test_file(directory: Path, filename: str) -> Path:
    """Create an empty test Excel file"""
    path = directory / filename
    path.write_bytes(b"fake excel content")
    return path


# ============================================================
# SECTION 1: Mock tests - filename parsing
# ============================================================
class TestFilenameParsingMock:
    """Filename parsing - no real files needed"""

    def setup_method(self):
        with patch("utils.file_manager.FILE_CONFIG", {
            "landing_path":    "/tmp/landing",
            "archive_path":    "/tmp/archive",
            "quarantine_path": "/tmp/quarantine",
            "processed_path":  "/tmp/processed"
        }):
            self.mgr = FileManager.__new__(FileManager)
            import re
            import yaml
            from pathlib import Path as P
            config_path = P(__file__).parent.parent / "config" / "pipeline_config.yaml"
            with open(config_path) as f:
                _config = yaml.safe_load(f)
            self.mgr.filename_pattern = re.compile(
                _config["excel"]["filename_pattern"],
                re.IGNORECASE
            )
            self.mgr.landing_path    = P("/tmp/landing")
            self.mgr.archive_path    = P("/tmp/archive")
            self.mgr.quarantine_path = P("/tmp/quarantine")

    def _parse(self, filename):
        return self.mgr._parse_filename(Path(filename))

    def test_standard_filename_parsed(self):
        result = self._parse("ICF_Residential_2026_04.xlsx")
        assert result is not None
        assert result["year"] == 2026
        assert result["month"] == 4

    def test_period_sk_yyyymmdd_format(self):
        result = self._parse("ICF_2026_04.xlsx")
        assert result["period_sk"] == 20260401

    def test_period_sk_day_always_01(self):
        """Day portion of PERIOD_SK always 01 for monthly grain"""
        result = self._parse("Vendor_2026_12.xlsx")
        assert str(result["period_sk"]).endswith("01")

    def test_data_date_correct(self):
        result = self._parse("ICF_2026_04.xlsx")
        assert result["data_date"] == date(2026, 4, 1)

    def test_reporting_period_human_readable(self):
        result = self._parse("ICF_2026_04.xlsx")
        assert result["reporting_period"] == "Apr 2026"

    def test_january_period(self):
        result = self._parse("Vendor_2026_01.xlsx")
        assert result["period_sk"] == 20260101
        assert result["reporting_period"] == "Jan 2026"

    def test_december_period(self):
        result = self._parse("Vendor_2025_12.xlsx")
        assert result["period_sk"] == 20251201
        assert result["reporting_period"] == "Dec 2025"

    def test_vendor_key_extracted(self):
        """Vendor key is filename without date and extension"""
        result = self._parse("ICF_Residential_LMI_2026_04.xlsx")
        assert result["vendor_key"] == "ICF_Residential_LMI"

    def test_simple_vendor_key(self):
        result = self._parse("ICF_2026_04.xlsx")
        assert result["vendor_key"] == "ICF"

    def test_invalid_filename_returns_none(self):
        result = self._parse("invalid_filename.xlsx")
        assert result is None

    def test_missing_month_returns_none(self):
        result = self._parse("ICF_2026.xlsx")
        assert result is None

    def test_non_xlsx_returns_none(self):
        result = self._parse("ICF_2026_04.csv")
        assert result is None

    def test_case_insensitive_extension(self):
        result = self._parse("ICF_2026_04.XLSX")
        assert result is not None

    def test_multi_part_vendor_name(self):
        result = self._parse("Eaton_Commercial_Small_Biz_2026_04.xlsx")
        assert result["vendor_key"] == "Eaton_Commercial_Small_Biz"
        assert result["month"] == 4
        assert result["year"] == 2026

    def test_get_period_sk_convenience(self):
        result = self.mgr.get_period_sk("ICF_2026_04.xlsx")
        assert result == 20260401

    def test_get_period_sk_invalid_returns_none(self):
        result = self.mgr.get_period_sk("invalid.xlsx")
        assert result is None


# ============================================================
# SECTION 2: Real file tests - scan landing zone
# ============================================================
class TestScanLandingZoneReal:
    """Tests using real temp files"""

    def test_finds_valid_files(self, file_mgr):
        mgr, dirs = file_mgr
        create_test_file(dirs["landing"], "ICF_2026_04.xlsx")
        create_test_file(dirs["landing"], "Eaton_2026_04.xlsx")
        files = mgr.scan_landing_zone()
        assert len(files) == 2

    def test_ignores_invalid_filenames(self, file_mgr):
        mgr, dirs = file_mgr
        create_test_file(dirs["landing"], "ICF_2026_04.xlsx")      # valid
        create_test_file(dirs["landing"], "invalid_file.xlsx")     # invalid
        create_test_file(dirs["landing"], "notes.txt")             # wrong type
        files = mgr.scan_landing_zone()
        assert len(files) == 1

    def test_empty_landing_zone(self, file_mgr):
        mgr, dirs = file_mgr
        files = mgr.scan_landing_zone()
        assert len(files) == 0

    def test_files_sorted_by_name(self, file_mgr):
        mgr, dirs = file_mgr
        create_test_file(dirs["landing"], "Vendor_Z_2026_04.xlsx")
        create_test_file(dirs["landing"], "Vendor_A_2026_04.xlsx")
        create_test_file(dirs["landing"], "Vendor_M_2026_04.xlsx")
        files = mgr.scan_landing_zone()
        names = [f["file_name"] for f in files]
        assert names == sorted(names)

    def test_returns_all_file_info_fields(self, file_mgr):
        mgr, dirs = file_mgr
        create_test_file(dirs["landing"], "ICF_Residential_2026_04.xlsx")
        files = mgr.scan_landing_zone()
        assert len(files) == 1
        f = files[0]
        assert "file_path" in f
        assert "file_name" in f
        assert "vendor_key" in f
        assert "period_sk" in f
        assert "data_date" in f
        assert "reporting_period" in f


# ============================================================
# SECTION 3: Real file tests - archive
# ============================================================
class TestArchiveReal:

    def test_file_moved_to_archive(self, file_mgr):
        mgr, dirs = file_mgr
        file_path = create_test_file(
            dirs["landing"], "ICF_2026_04.xlsx"
        )
        archive_path = mgr.archive_file(file_path)
        assert not file_path.exists()
        assert archive_path.exists()

    def test_archive_creates_year_month_subfolder(self, file_mgr):
        mgr, dirs = file_mgr
        file_path = create_test_file(
            dirs["landing"], "ICF_2026_04.xlsx"
        )
        archive_path = mgr.archive_file(file_path)
        # Should be under archive/2026/04/
        assert "2026" in str(archive_path)
        assert "04" in str(archive_path)

    def test_archive_adds_timestamp_to_name(self, file_mgr):
        mgr, dirs = file_mgr
        file_path = create_test_file(
            dirs["landing"], "ICF_2026_04.xlsx"
        )
        archive_path = mgr.archive_file(file_path)
        # Archived name should differ from original
        assert archive_path.name != "ICF_2026_04.xlsx"

    def test_archive_returns_path(self, file_mgr):
        mgr, dirs = file_mgr
        file_path = create_test_file(
            dirs["landing"], "ICF_2026_04.xlsx"
        )
        result = mgr.archive_file(file_path)
        assert isinstance(result, Path)
        assert result.exists()


# ============================================================
# SECTION 4: Real file tests - quarantine
# ============================================================
class TestQuarantineReal:

    def test_file_moved_to_quarantine(self, file_mgr):
        mgr, dirs = file_mgr
        file_path = create_test_file(
            dirs["landing"], "Bad_Vendor_2026_04.xlsx"
        )
        q_path = mgr.quarantine_file(file_path, "Validation failed")
        assert not file_path.exists()
        assert q_path.exists()

    def test_quarantine_name_contains_quarantine(self, file_mgr):
        mgr, dirs = file_mgr
        file_path = create_test_file(
            dirs["landing"], "Bad_Vendor_2026_04.xlsx"
        )
        q_path = mgr.quarantine_file(file_path)
        assert "QUARANTINE" in q_path.name

    def test_quarantine_returns_path(self, file_mgr):
        mgr, dirs = file_mgr
        file_path = create_test_file(
            dirs["landing"], "Bad_Vendor_2026_04.xlsx"
        )
        result = mgr.quarantine_file(file_path, "reason")
        assert isinstance(result, Path)
        assert result.exists()

    def test_quarantine_no_reason(self, file_mgr):
        """Quarantine should work without reason"""
        mgr, dirs = file_mgr
        file_path = create_test_file(
            dirs["landing"], "Bad_2026_04.xlsx"
        )
        q_path = mgr.quarantine_file(file_path)
        assert q_path.exists()


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
