# ============================================================
# CES Savings ETL - Main Pipeline Tests
# Tests for multi-sheet fix, archive timing,
# batch status, resubmission handling
# Run with: pytest tests/test_main.py -v
# ============================================================

import sys
import pytest
from pathlib import Path
from datetime import date
from unittest.mock import patch, MagicMock, call

sys.path.insert(0, str(Path(__file__).parent.parent))

import main as pipeline


# ============================================================
# FIXTURES - Mock all external dependencies
# ============================================================
@pytest.fixture
def mock_file_info():
    return {
        "file_path":        Path("/tmp/landing/ICF_2026_04.xlsx"),
        "file_name":        "ICF_2026_04.xlsx",
        "vendor_key":       "ICF",
        "period_sk":        20260401,
        "data_date":        date(2026, 4, 1),
        "reporting_period": "Apr 2026",
        "year":             2026,
        "month":            4
    }


@pytest.fixture
def mock_audit():
    audit = MagicMock()
    audit.start_batch.return_value = 1
    audit.start_file.return_value = 101
    return audit


@pytest.fixture
def mock_db():
    """Mock database with sample column mapping"""
    mock = MagicMock()
    mock.load_column_mapping.return_value = [
        {
            "EXCEL_ROW1_HEADER": "",
            "EXCEL_ROW2_HEADER": "",
            "EXCEL_ROW3_HEADER": "Vendor Subprogram Key",
            "STG_COLUMN_NAME":   "VENDOR_SUBPROGRAM_KEY",
            "FACT_COLUMN_NAME":  "VENDOR_SUBPROGRAM_KEY",
            "DATA_TYPE":         "VARCHAR2",
            "IS_DIMENSION":      "Y",
            "IS_REQUIRED":       "Y",
            "IS_STOP_COLUMN":    "Y"
        }
    ]
    return mock


# ============================================================
# SECTION 1: Mock tests - multi-sheet fix
# ============================================================
class TestMultiSheetFixMock:
    """
    Critical: File must stay in landing until ALL sheets processed.
    Archive only AFTER both Savings Results and Savings Forecast done.
    """

    def test_process_file_does_not_archive(self, mock_file_info, mock_audit):
        """
        process_file() must NOT archive the file.
        Archiving belongs in run_pipeline after all sheets done.
        """
        import inspect
        source = inspect.getsource(pipeline.process_file)
        assert "archive_file" not in source, \
            "process_file() should not call archive_file()"

    def test_process_file_does_not_quarantine_directly(self, mock_file_info, mock_audit):
        """
        process_file() must NOT quarantine the file directly.
        It should only return a status - quarantine in run_pipeline.
        """
        import inspect
        source = inspect.getsource(pipeline.process_file)
        assert "quarantine_file" not in source, \
            "process_file() should not call quarantine_file()"

    def test_run_pipeline_archives_after_both_sheets(self):
        """
        Archive should be called once per file,
        AFTER both sheets processed.
        """
        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {
                "file_path": Path("/tmp/ICF_2026_04.xlsx"),
                "file_name": "ICF_2026_04.xlsx",
                "vendor_key": "ICF",
                "period_sk": 20260401,
                "data_date": date(2026, 4, 1),
                "reporting_period": "Apr 2026"
            }
        ]

        # Both sheets succeed
        success_stats = {
            "status": "SUCCESS",
            "rows_source": 100,
            "rows_loaded": 100,
            "rows_failed": 0,
            "is_resubmission": False
        }

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file", return_value=success_stats), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            pipeline.run_pipeline()

        # Archive called exactly once (after both sheets)
        mock_file_mgr.archive_file.assert_called_once()

    def test_run_pipeline_quarantines_if_actuals_fail(self):
        """
        If actuals sheet fails, whole file should be quarantined.
        Forecast sheet should still be attempted.
        """
        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {
                "file_path": Path("/tmp/ICF_2026_04.xlsx"),
                "file_name": "ICF_2026_04.xlsx",
                "vendor_key": "ICF",
                "period_sk": 20260401,
                "data_date": date(2026, 4, 1),
                "reporting_period": "Apr 2026"
            }
        ]

        def sheet_results(file_info, sheet_key, *args, **kwargs):
            if sheet_key == "savings_results":
                return {"status": "QUARANTINE", "rows_source": 100,
                        "rows_loaded": 0, "rows_failed": 100,
                        "is_resubmission": False}
            return {"status": "SUCCESS", "rows_source": 100,
                    "rows_loaded": 100, "rows_failed": 0,
                    "is_resubmission": False}

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file", side_effect=sheet_results), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            pipeline.run_pipeline()

        # Should quarantine not archive
        mock_file_mgr.quarantine_file.assert_called_once()
        mock_file_mgr.archive_file.assert_not_called()

    def test_run_pipeline_quarantines_if_forecast_fails(self):
        """
        If forecast sheet fails after actuals succeed,
        whole file quarantined (not archived).
        """
        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {
                "file_path": Path("/tmp/ICF_2026_04.xlsx"),
                "file_name": "ICF_2026_04.xlsx",
                "vendor_key": "ICF",
                "period_sk": 20260401,
                "data_date": date(2026, 4, 1),
                "reporting_period": "Apr 2026"
            }
        ]

        def sheet_results(file_info, sheet_key, *args, **kwargs):
            if sheet_key == "savings_results":
                return {"status": "SUCCESS", "rows_source": 100,
                        "rows_loaded": 100, "rows_failed": 0,
                        "is_resubmission": False}
            # Forecast fails
            return {"status": "FAILED", "rows_source": 100,
                    "rows_loaded": 0, "rows_failed": 100,
                    "is_resubmission": False}

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file", side_effect=sheet_results), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            pipeline.run_pipeline()

        # File touched by both sheets but overall quarantined
        mock_file_mgr.quarantine_file.assert_called_once()
        mock_file_mgr.archive_file.assert_not_called()


# ============================================================
# SECTION 2: Mock tests - batch status
# ============================================================
class TestBatchStatusMock:

    def _run_with_results(self, file_results_by_sheet):
        """Helper to run pipeline with predetermined sheet results"""
        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {
                "file_path": Path("/tmp/ICF_2026_04.xlsx"),
                "file_name": "ICF_2026_04.xlsx",
                "vendor_key": "ICF",
                "period_sk": 20260401,
                "data_date": date(2026, 4, 1),
                "reporting_period": "Apr 2026"
            }
        ]

        captured_status = {}

        def capture_complete_batch(**kwargs):
            captured_status["status"] = kwargs.get("status")

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file",
                   side_effect=lambda fi, sk, *a, **kw:
                   file_results_by_sheet.get(sk, {
                       "status": "SUCCESS", "rows_source": 0,
                       "rows_loaded": 0, "rows_failed": 0,
                       "is_resubmission": False
                   })), \
             patch("main.db"):

            mock_audit = MagicMock()
            mock_audit.start_batch.return_value = 1
            mock_audit.complete_batch.side_effect = \
                lambda batch_id, **kw: captured_status.update({"status": kw["status"]})
            mock_audit_cls.return_value = mock_audit

            exit_code = pipeline.run_pipeline()

        return exit_code, captured_status.get("status")

    def test_all_succeed_status_success(self):
        exit_code, status = self._run_with_results({
            "savings_results":  {"status": "SUCCESS", "rows_source": 100,
                                 "rows_loaded": 100, "rows_failed": 0,
                                 "is_resubmission": False},
            "savings_forecast": {"status": "SUCCESS", "rows_source": 100,
                                 "rows_loaded": 100, "rows_failed": 0,
                                 "is_resubmission": False}
        })
        assert exit_code == 0
        assert status == "SUCCESS"

    def test_all_fail_status_failed(self):
        exit_code, status = self._run_with_results({
            "savings_results":  {"status": "FAILED", "rows_source": 100,
                                 "rows_loaded": 0, "rows_failed": 100,
                                 "is_resubmission": False},
            "savings_forecast": {"status": "FAILED", "rows_source": 100,
                                 "rows_loaded": 0, "rows_failed": 100,
                                 "is_resubmission": False}
        })
        assert exit_code == 1

    def test_no_files_returns_success(self):
        """Empty landing zone should complete without error"""
        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = []

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            exit_code = pipeline.run_pipeline()

        assert exit_code == 0


# ============================================================
# SECTION 3: Mock tests - single sheet run
# ============================================================
class TestSingleSheetMock:

    def test_run_actuals_only(self):
        """--sheets savings_results should only process actuals"""
        processed_sheets = []

        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {
                "file_path": Path("/tmp/ICF_2026_04.xlsx"),
                "file_name": "ICF_2026_04.xlsx",
                "vendor_key": "ICF",
                "period_sk": 20260401,
                "data_date": date(2026, 4, 1),
                "reporting_period": "Apr 2026"
            }
        ]

        def capture_sheet(file_info, sheet_key, *args, **kwargs):
            processed_sheets.append(sheet_key)
            return {"status": "SUCCESS", "rows_source": 100,
                    "rows_loaded": 100, "rows_failed": 0,
                    "is_resubmission": False}

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file", side_effect=capture_sheet), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            pipeline.run_pipeline(sheets=["savings_results"])

        assert processed_sheets == ["savings_results"]
        assert "savings_forecast" not in processed_sheets

    def test_run_forecast_only(self):
        """--sheets savings_forecast should only process forecast"""
        processed_sheets = []

        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {
                "file_path": Path("/tmp/ICF_2026_04.xlsx"),
                "file_name": "ICF_2026_04.xlsx",
                "vendor_key": "ICF",
                "period_sk": 20260401,
                "data_date": date(2026, 4, 1),
                "reporting_period": "Apr 2026"
            }
        ]

        def capture_sheet(file_info, sheet_key, *args, **kwargs):
            processed_sheets.append(sheet_key)
            return {"status": "SUCCESS", "rows_source": 100,
                    "rows_loaded": 100, "rows_failed": 0,
                    "is_resubmission": False}

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file", side_effect=capture_sheet), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            pipeline.run_pipeline(sheets=["savings_forecast"])

        assert processed_sheets == ["savings_forecast"]
        assert "savings_results" not in processed_sheets

    def test_both_sheets_default(self):
        """Default run should process both sheets"""
        processed_sheets = []

        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {
                "file_path": Path("/tmp/ICF_2026_04.xlsx"),
                "file_name": "ICF_2026_04.xlsx",
                "vendor_key": "ICF",
                "period_sk": 20260401,
                "data_date": date(2026, 4, 1),
                "reporting_period": "Apr 2026"
            }
        ]

        def capture_sheet(file_info, sheet_key, *args, **kwargs):
            processed_sheets.append(sheet_key)
            return {"status": "SUCCESS", "rows_source": 100,
                    "rows_loaded": 100, "rows_failed": 0,
                    "is_resubmission": False}

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file", side_effect=capture_sheet), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            pipeline.run_pipeline()

        assert "savings_results" in processed_sheets
        assert "savings_forecast" in processed_sheets


# ============================================================
# SECTION 4: Mock tests - multiple files
# ============================================================
class TestMultipleFilesMock:

    def test_all_files_processed(self):
        """All 3 files in landing should be processed"""
        processed_files = []

        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {"file_path": Path(f"/tmp/Vendor_{i}_2026_04.xlsx"),
             "file_name": f"Vendor_{i}_2026_04.xlsx",
             "vendor_key": f"Vendor_{i}",
             "period_sk": 20260401, "data_date": date(2026, 4, 1),
             "reporting_period": "Apr 2026"}
            for i in range(3)
        ]

        def capture_file(file_info, sheet_key, *args, **kwargs):
            processed_files.append(file_info["vendor_key"])
            return {"status": "SUCCESS", "rows_source": 100,
                    "rows_loaded": 100, "rows_failed": 0,
                    "is_resubmission": False}

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file", side_effect=capture_file), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            pipeline.run_pipeline()

        # Each vendor processed for both sheets = 6 calls total
        assert len(processed_files) == 6
        # Each vendor appears twice (once per sheet)
        for i in range(3):
            assert processed_files.count(f"Vendor_{i}") == 2

    def test_one_file_fails_others_continue(self):
        """One failed file should not stop other files"""
        archived_files = []

        mock_file_mgr = MagicMock()
        mock_file_mgr.scan_landing_zone.return_value = [
            {"file_path": Path(f"/tmp/Vendor_{i}_2026_04.xlsx"),
             "file_name": f"Vendor_{i}_2026_04.xlsx",
             "vendor_key": f"Vendor_{i}",
             "period_sk": 20260401, "data_date": date(2026, 4, 1),
             "reporting_period": "Apr 2026"}
            for i in range(3)
        ]

        mock_file_mgr.archive_file.side_effect = \
            lambda p: archived_files.append(p) or p

        def mixed_results(file_info, sheet_key, *args, **kwargs):
            if file_info["vendor_key"] == "Vendor_1":
                return {"status": "FAILED", "rows_source": 100,
                        "rows_loaded": 0, "rows_failed": 100,
                        "is_resubmission": False}
            return {"status": "SUCCESS", "rows_source": 100,
                    "rows_loaded": 100, "rows_failed": 0,
                    "is_resubmission": False}

        with patch("main.FileManager", return_value=mock_file_mgr), \
             patch("main.AuditLogger") as mock_audit_cls, \
             patch("main.Notifier"), \
             patch("main.process_file", side_effect=mixed_results), \
             patch("main.db"):

            mock_audit_cls.return_value.start_batch.return_value = 1
            pipeline.run_pipeline()

        # 2 files archived (Vendor_0 and Vendor_2), 1 failed
        assert mock_file_mgr.archive_file.call_count == 2


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
