# ============================================================
# CES Savings ETL - Extractor Tests
# Tests for clean_header, header propagation,
# column mapping lookup, stop condition
# Run with: pytest tests/test_extractor.py -v
# ============================================================

import sys
import re
import pytest
import openpyxl
from pathlib import Path
from unittest.mock import patch, MagicMock
from io import BytesIO

sys.path.insert(0, str(Path(__file__).parent.parent))

from etl.extractor import ExcelExtractor, clean_header

# ============================================================
# SAMPLE COLUMN MAPPING
# Mirrors CES_SAVINGS_COLUMN_MAP for testing
# ============================================================
SAMPLE_MAPPING = [
    # Dimension columns
    # EXCEL_COL_POSITION is 1-based (matches Excel column number)
    {
        "EXCEL_COL_POSITION": 1,
        "EXCEL_ROW1_HEADER": "", "EXCEL_ROW2_HEADER": "",
        "EXCEL_ROW3_HEADER": "Vendor Subprogram Key",
        "ROW1_EXPECTED": "", "ROW2_EXPECTED": "",
        "FUZZY_THRESHOLD": 75,
        "STG_COLUMN_NAME": "VENDOR_SUBPROGRAM_KEY",
        "FACT_COLUMN_NAME": "VENDOR_SUBPROGRAM_KEY",
        "DATA_TYPE": "VARCHAR2", "IS_DIMENSION": "Y",
        "IS_REQUIRED": "Y", "IS_STOP_COLUMN": "Y"
    },
    {
        "EXCEL_COL_POSITION": 2,
        "EXCEL_ROW1_HEADER": "", "EXCEL_ROW2_HEADER": "",
        "EXCEL_ROW3_HEADER": "Reporting Period",
        "ROW1_EXPECTED": "", "ROW2_EXPECTED": "",
        "FUZZY_THRESHOLD": 75,
        "STG_COLUMN_NAME": "REPORTING_PERIOD",
        "FACT_COLUMN_NAME": "REPORTING_PERIOD",
        "DATA_TYPE": "VARCHAR2", "IS_DIMENSION": "Y",
        "IS_REQUIRED": "Y", "IS_STOP_COLUMN": "N"
    },
    {
        "EXCEL_COL_POSITION": 3,
        "EXCEL_ROW1_HEADER": "", "EXCEL_ROW2_HEADER": "",
        "EXCEL_ROW3_HEADER": "Sector",
        "ROW1_EXPECTED": "", "ROW2_EXPECTED": "",
        "FUZZY_THRESHOLD": 75,
        "STG_COLUMN_NAME": "SECTOR",
        "FACT_COLUMN_NAME": "SECTOR",
        "DATA_TYPE": "VARCHAR2", "IS_DIMENSION": "Y",
        "IS_REQUIRED": "N", "IS_STOP_COLUMN": "N"
    },
    # Financial columns
    {
        "EXCEL_COL_POSITION": 5,
        "EXCEL_ROW1_HEADER": "", "EXCEL_ROW2_HEADER": "Financials",
        "EXCEL_ROW3_HEADER": "Investment - Rebate",
        "ROW1_EXPECTED": "", "ROW2_EXPECTED": "Financials",
        "FUZZY_THRESHOLD": 75,
        "STG_COLUMN_NAME": "INVEST_COST_REBATE",
        "FACT_COLUMN_NAME": "INVEST_COST_REBATE",
        "DATA_TYPE": "NUMBER_2", "IS_DIMENSION": "N",
        "IS_REQUIRED": "N", "IS_STOP_COLUMN": "N"
    },
    {
        "EXCEL_COL_POSITION": 6,
        "EXCEL_ROW1_HEADER": "", "EXCEL_ROW2_HEADER": "Financials",
        "EXCEL_ROW3_HEADER": "Investment - OBR",
        "ROW1_EXPECTED": "", "ROW2_EXPECTED": "Financials",
        "FUZZY_THRESHOLD": 75,
        "STG_COLUMN_NAME": "INVEST_COST_OBR",
        "FACT_COLUMN_NAME": "INVEST_COST_OBR",
        "DATA_TYPE": "NUMBER_2", "IS_DIMENSION": "N",
        "IS_REQUIRED": "N", "IS_STOP_COLUMN": "N"
    },
    # Metric columns
    {
        "EXCEL_COL_POSITION": 7,
        "EXCEL_ROW1_HEADER": "Electric",
        "EXCEL_ROW2_HEADER": "Gross Site Savings (Exclude IEs) TRM Protocol",
        "EXCEL_ROW3_HEADER": "Gross Site Annual Electric Savings - kWh",
        "ROW1_EXPECTED": "Electric",
        "ROW2_EXPECTED": "Gross Site Savings (Exclude IEs) TRM Protocol",
        "FUZZY_THRESHOLD": 75,
        "STG_COLUMN_NAME": "GROSS_SITE_ELEC_ANNUAL_KWH",
        "FACT_COLUMN_NAME": "GROSS_SITE_ELEC_ANNUAL_KWH",
        "DATA_TYPE": "NUMBER_4", "IS_DIMENSION": "N",
        "IS_REQUIRED": "N", "IS_STOP_COLUMN": "N"
    },
    {
        "EXCEL_COL_POSITION": 8,
        "EXCEL_ROW1_HEADER": "Natural Gas",
        "EXCEL_ROW2_HEADER": "Gross Site Savings (Exclude IEs) TRM Protocol",
        "EXCEL_ROW3_HEADER": "Gross Site Annual Gas Savings - Therms",
        "ROW1_EXPECTED": "Natural Gas",
        "ROW2_EXPECTED": "Gross Site Savings (Exclude IEs) TRM Protocol",
        "FUZZY_THRESHOLD": 75,
        "STG_COLUMN_NAME": "GROSS_SITE_GAS_ANNUAL_THERMS",
        "FACT_COLUMN_NAME": "GROSS_SITE_GAS_ANNUAL_THERMS",
        "DATA_TYPE": "NUMBER_4", "IS_DIMENSION": "N",
        "IS_REQUIRED": "N", "IS_STOP_COLUMN": "N"
    }
]

SHEET_CONFIG = {
    "sheet_name":      "Savings Results",
    "header_row":      3,
    "row1_header_row": 1,
    "row2_header_row": 2,
    "data_start_row":  4,
    "stop_column":     "Vendor Subprogram Key",
    "stg_table":       "CES_SAVINGS_STG_ACTUALS"
}


# ============================================================
# HELPER: Create in-memory Excel file
# ============================================================
def make_excel_file(
    row1=None, row2=None, row3=None,
    data_rows=None, sheet_name="Savings Results"
) -> Path:
    """
    Build an Excel file in /tmp for testing.
    Returns Path to the file.
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet_name

    # Row 1: energy type headers
    if row1:
        ws.append(row1)
    else:
        ws.append(["", "", "", "", "", "Electric", None, "Natural Gas", None])

    # Row 2: calc method headers
    if row2:
        ws.append(row2)
    else:
        ws.append([
            "", "", "", "", "Financials", None,
            "Gross Site Savings (Exclude IEs) TRM Protocol", None, None
        ])

    # Row 3: actual column headers
    if row3:
        ws.append(row3)
    else:
        ws.append([
            "Vendor Subprogram Key", "Reporting Period", "Sector",
            "Program",
            "Investment - Rebate", "Investment - OBR",
            "Gross Site Annual Electric Savings - kWh",
            "Gross Site Annual Gas Savings - Therms",
            "Extra Column Should Be Ignored"
        ])

    # Data rows
    if data_rows:
        for row in data_rows:
            ws.append(row)

    path = Path("/tmp/test_vendor_2026_04.xlsx")
    wb.save(str(path))
    return path


# ============================================================
# SECTION 1: clean_header tests (with mock)
# ============================================================
class TestCleanHeaderMock:
    """Unit tests for clean_header - no file I/O needed"""

    def test_basic_text(self):
        assert clean_header("Annual Electric Savings kWh") == \
               "ANNUAL_ELECTRIC_SAVINGS_KWH"

    def test_special_chars_removed(self):
        assert clean_header("Investment - Rebate") == "INVESTMENT_REBATE"

    def test_slash_removed(self):
        assert clean_header("Therms/day") == "THERMSDAY"

    def test_parentheses_removed(self):
        assert clean_header("OBC Only (All Projects)") == "OBC_ONLY_ALL_PROJECTS"

    def test_line_break(self):
        assert clean_header("Net Realized\nSite Annual") == \
               "NET_REALIZED_SITE_ANNUAL"

    def test_carriage_return(self):
        assert clean_header("Net Realized\r\nSite") == "NET_REALIZED_SITE"

    def test_none_returns_empty(self):
        assert clean_header(None) == ""

    def test_empty_string(self):
        assert clean_header("") == ""

    def test_blank_spaces(self):
        assert clean_header("   ") == ""

    def test_unnamed_column(self):
        assert clean_header("Unnamed: 5") == ""

    def test_multiple_spaces(self):
        assert clean_header("Res LMI  or   OBC") == "RES_LMI_OR_OBC"

    def test_uppercase(self):
        assert clean_header("annual electric") == "ANNUAL_ELECTRIC"

    def test_leading_trailing_underscore(self):
        result = clean_header(" - Investment")
        assert not result.startswith("_")
        assert not result.endswith("_")

    def test_consecutive_underscores(self):
        result = clean_header("Net  Realized   Site")
        assert "__" not in result

    # Number prefix tests (cost column fix)
    def test_number_prefix_paren(self):
        """1) Investment - Rebate should clean same as Investment - Rebate"""
        assert clean_header("1) Investment - Rebate") == \
               clean_header("Investment - Rebate")

    def test_number_prefix_dot(self):
        assert clean_header("2. Investment - OBR") == \
               clean_header("Investment - OBR")

    def test_number_prefix_dash(self):
        assert clean_header("3- Investment - Other") == \
               clean_header("Investment - Other")

    def test_number_prefix_space(self):
        assert clean_header("1 Investment Rebate") != ""


# ============================================================
# SECTION 2: Header propagation tests (with mock)
# ============================================================
class TestHeaderPropagationMock:
    """Test merged cell value propagation - no file I/O"""

    def setup_method(self):
        self.extractor = ExcelExtractor(SAMPLE_MAPPING, SHEET_CONFIG)

    def test_propagates_non_null_forward(self):
        row = ("Electric", None, None, "Natural Gas", None)
        result = self.extractor._propagate_merged(row)
        assert result == ["Electric", "Electric", "Electric", "Natural Gas", "Natural Gas"]

    def test_empty_before_first_value(self):
        row = (None, None, "Electric", None)
        result = self.extractor._propagate_merged(row)
        assert result == ["", "", "Electric", "Electric"]

    def test_all_none(self):
        row = (None, None, None)
        result = self.extractor._propagate_merged(row)
        assert result == ["", "", ""]

    def test_all_values(self):
        row = ("A", "B", "C")
        result = self.extractor._propagate_merged(row)
        assert result == ["A", "B", "C"]

    def test_single_value(self):
        row = (None, "Electric", None, None)
        result = self.extractor._propagate_merged(row)
        assert result == ["", "Electric", "Electric", "Electric"]

    def test_blank_string_not_propagated(self):
        row = ("Electric", "", None, "Natural Gas")
        result = self.extractor._propagate_merged(row)
        # blank string treated same as None - last real value propagates
        assert result[2] in ("Electric", "")


# ============================================================
# SECTION 3: Column mapping lookup tests (with mock)
# ============================================================
class TestColumnMappingLookupMock:
    """Test mapping lookup logic - no file I/O"""

    def setup_method(self):
        self.extractor = ExcelExtractor(SAMPLE_MAPPING, SHEET_CONFIG)

    def test_dimension_column_mapped(self):
        """Dimension columns have blank row1 and row2"""
        col_map = self.extractor._map_columns(
            row1=["", "", "", "", "", "Electric", "Electric"],
            row2=["", "", "", "", "Financials", "Financials",
                  "Gross Site Savings Exclude IEs TRM Protocol"],
            row3=("Vendor Subprogram Key", "Reporting Period",
                  "Sector", "Program",
                  "Investment - Rebate", "Investment - OBR",
                  "Gross Site Annual Electric Savings - kWh")
        )
        assert 0 in col_map
        assert col_map[0] == "VENDOR_SUBPROGRAM_KEY"

    def test_financial_column_mapped(self):
        """Financial columns have Financials in row2"""
        col_map = self.extractor._map_columns(
            row1=["", "", "", "", "", "Electric"],
            row2=["", "", "", "Financials", "Financials",
                  "Gross Site Savings Exclude IEs TRM Protocol"],
            row3=("Vendor Subprogram Key", "Reporting Period",
                  "Sector",
                  "Investment - Rebate", "Investment - OBR",
                  "Gross Site Annual Electric Savings - kWh")
        )
        assert col_map.get(3) == "INVEST_COST_REBATE"
        assert col_map.get(4) == "INVEST_COST_OBR"

    def test_numbered_financial_column_mapped(self):
        """
        Cost columns with number prefix e.g. '1) Investment - Rebate'
        should map to same Oracle column as 'Investment - Rebate'
        """
        col_map = self.extractor._map_columns(
            row1=["", "", "", ""],
            row2=["", "", "Financials", "Financials"],
            row3=("Vendor Subprogram Key",
                  "Reporting Period",
                  "1) Investment - Rebate",  # ← number prefix
                  "2) Investment - OBR")     # ← number prefix
        )
        assert col_map.get(2) == "INVEST_COST_REBATE"
        assert col_map.get(3) == "INVEST_COST_OBR"

    def test_metric_column_mapped(self):
        """Metric columns need all three header levels"""
        col_map = self.extractor._map_columns(
            row1=["", "", "Electric"],
            row2=["", "",
                  "Gross Site Savings Exclude IEs TRM Protocol"],
            row3=("Vendor Subprogram Key",
                  "Reporting Period",
                  "Gross Site Annual Electric Savings - kWh")
        )
        assert col_map.get(2) == "GROSS_SITE_ELEC_ANNUAL_KWH"

    def test_unmapped_column_ignored(self):
        """Extra columns not in mapping are silently ignored"""
        col_map = self.extractor._map_columns(
            row1=["", "", ""],
            row2=["", "", ""],
            row3=("Vendor Subprogram Key",
                  "Reporting Period",
                  "This Column Does Not Exist In Mapping")
        )
        assert 2 not in col_map

    def test_blank_header_skipped(self):
        """Blank row3 header should not be mapped"""
        col_map = self.extractor._map_columns(
            row1=["", "", ""],
            row2=["", "", ""],
            row3=("Vendor Subprogram Key", "", None)
        )
        assert 1 not in col_map
        assert 2 not in col_map

    def test_stop_column_identified(self):
        """VENDOR_SUBPROGRAM_KEY should be the stop column"""
        assert self.extractor._stop_column == "VENDOR_SUBPROGRAM_KEY"


# ============================================================
# SECTION 4: Extract tests (with real Excel file)
# ============================================================
class TestExtractorReal:
    """Integration tests using real in-memory Excel files"""

    def setup_method(self):
        self.extractor = ExcelExtractor(SAMPLE_MAPPING, SHEET_CONFIG)

    def test_extracts_correct_row_count(self):
        """3 data rows should extract as 3 rows"""
        path = make_excel_file(data_rows=[
            ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
             1000.00, 500.00, 15000.0, 200.0, "ignored"],
            ["ICF_002", "Apr 2026", "Commercial", "CEF-EE II",
             2000.00, 600.00, 20000.0, 300.0, "ignored"],
            ["ICF_003", "Apr 2026", "Residential", "CEF-EE II",
             3000.00, 700.00, 25000.0, 400.0, "ignored"]
        ])
        df, rows_source = self.extractor.extract(path)
        assert len(df) == 3
        assert rows_source >= 3

    def test_stops_at_blank_vendor_key(self):
        """Rows after blank VENDOR_SUBPROGRAM_KEY should not load"""
        path = make_excel_file(data_rows=[
            ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
             1000.00, 500.00, 15000.0, 200.0, "ignored"],
            ["ICF_002", "Apr 2026", "Commercial", "CEF-EE II",
             2000.00, 600.00, 20000.0, 300.0, "ignored"],
            # Stop condition: blank vendor key
            [None, None, None, None, None, None, None, None, None],
            # This row should NOT be loaded
            ["ICF_003", "Apr 2026", "Residential", "CEF-EE II",
             3000.00, 700.00, 25000.0, 400.0, "ignored"]
        ])
        df, rows_source = self.extractor.extract(path)
        assert len(df) == 2

    def test_stops_at_empty_string_vendor_key(self):
        """Empty string vendor key also triggers stop"""
        path = make_excel_file(data_rows=[
            ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
             1000.00, 500.00, 15000.0, 200.0, "ignored"],
            ["", None, None, None, None, None, None, None, None],
            ["ICF_002", "Apr 2026", "Commercial", "CEF-EE II",
             2000.00, 600.00, 20000.0, 300.0, "ignored"]
        ])
        df, rows_source = self.extractor.extract(path)
        assert len(df) == 1

    def test_extra_columns_ignored(self):
        """Columns not in mapping should not appear in output"""
        path = make_excel_file(data_rows=[
            ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
             1000.00, 500.00, 15000.0, 200.0, "SHOULD_BE_IGNORED"]
        ])
        df, _ = self.extractor.extract(path)
        assert "SHOULD_BE_IGNORED" not in df.columns
        assert "Extra Column Should Be Ignored" not in df.columns

    def test_mapped_columns_present(self):
        """All mapped columns should be in output DataFrame"""
        path = make_excel_file(data_rows=[
            ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
             1000.00, 500.00, 15000.0, 200.0, "ignored"]
        ])
        df, _ = self.extractor.extract(path)
        assert "VENDOR_SUBPROGRAM_KEY" in df.columns
        assert "REPORTING_PERIOD" in df.columns
        assert "INVEST_COST_REBATE" in df.columns
        assert "GROSS_SITE_ELEC_ANNUAL_KWH" in df.columns

    def test_vendor_key_value_correct(self):
        """Vendor key value should match source"""
        path = make_excel_file(data_rows=[
            ["ICF_RESIDENTIAL_001", "Apr 2026", "Residential",
             "CEF-EE II", 1000.00, 500.00, 15000.0, 200.0, "ignored"]
        ])
        df, _ = self.extractor.extract(path)
        assert df["VENDOR_SUBPROGRAM_KEY"].iloc[0] == "ICF_RESIDENTIAL_001"

    def test_cost_values_extracted(self):
        """Financial column values should be extracted correctly"""
        path = make_excel_file(data_rows=[
            ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
             1234.56, 789.01, 15000.0, 200.0, "ignored"]
        ])
        df, _ = self.extractor.extract(path)
        assert df["INVEST_COST_REBATE"].iloc[0] == 1234.56
        assert df["INVEST_COST_OBR"].iloc[0] == 789.01

    def test_null_value_preserved(self):
        """NULL in source should remain None in output"""
        path = make_excel_file(data_rows=[
            ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
             None, None, None, None, "ignored"]
        ])
        df, _ = self.extractor.extract(path)
        assert df["INVEST_COST_REBATE"].iloc[0] is None
        assert df["GROSS_SITE_ELEC_ANNUAL_KWH"].iloc[0] is None

    def test_wrong_sheet_name_raises(self):
        """Wrong sheet name should raise ValueError"""
        path = make_excel_file(sheet_name="Wrong Sheet")
        with pytest.raises(ValueError, match="not found"):
            self.extractor.extract(path)

    def test_empty_file_returns_empty_df(self):
        """File with no data rows returns empty DataFrame"""
        path = make_excel_file(data_rows=[])
        df, rows_source = self.extractor.extract(path)
        assert len(df) == 0

    def test_numbered_cost_headers_extracted(self):
        """
        Cost columns with number prefix e.g. '1) Investment - Rebate'
        should still map correctly to INVEST_COST_REBATE
        """
        # Override row3 with numbered headers
        path = make_excel_file(
            row3=[
                "Vendor Subprogram Key", "Reporting Period", "Sector",
                "Program",
                "1) Investment - Rebate",   # ← numbered
                "2) Investment - OBR",      # ← numbered
                "Gross Site Annual Electric Savings - kWh",
                "Gross Site Annual Gas Savings - Therms",
                "Ignored"
            ],
            data_rows=[
                ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
                 5000.00, 2500.00, 15000.0, 200.0, "ignored"]
            ]
        )
        df, _ = self.extractor.extract(path)
        assert df["INVEST_COST_REBATE"].iloc[0] == 5000.00
        assert df["INVEST_COST_OBR"].iloc[0] == 2500.00

    def test_multiple_data_rows_all_extracted(self):
        """All data rows above stop condition extracted"""
        path = make_excel_file(data_rows=[
            ["ICF_001", "Apr 2026", "Residential", "CEF-EE II",
             1000.00, 500.00, 15000.0, 200.0, "ignored"],
            ["ICF_002", "Apr 2026", "Commercial", "CEF-EE II",
             2000.00, 600.00, 20000.0, 300.0, "ignored"],
            ["ICF_003", "Apr 2026", "Residential", "CEF-EE II",
             3000.00, 700.00, 25000.0, 400.0, "ignored"],
            ["ICF_004", "Apr 2026", "Commercial", "CEF-EE II",
             4000.00, 800.00, 30000.0, 500.0, "ignored"],
            ["ICF_005", "Apr 2026", "Residential", "CEF-EE II",
             5000.00, 900.00, 35000.0, 600.0, "ignored"]
        ])
        df, rows_source = self.extractor.extract(path)
        assert len(df) == 5


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
