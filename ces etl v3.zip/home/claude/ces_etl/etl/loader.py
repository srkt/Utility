# ============================================================
# CES Savings ETL - Loader
# Loads transformed data to STG then FACT tables
# Handles dimension lookups, resubmission versioning
# ============================================================

import logging
import pandas as pd
from typing import Optional

logger = logging.getLogger("ces_etl.loader")


class DataLoader:
    """
    Loads data into Oracle warehouse.

    Flow:
    1. Load raw to STG table (truncate first)
    2. Ensure DIM_VENDOR row exists (insert if new)
    3. Ensure DIM_PERIOD row exists (insert if new)
    4. Resolve VENDOR_SUBPROGRAM_SK
    5. Handle resubmission (version old rows)
    6. Insert to FACT table
    """

    def __init__(self, db, column_mapping: list, sheet_type: str):
        """
        Args:
            db: DatabaseManager instance
            column_mapping: column mapping list
            sheet_type: 'ACTUALS' or 'FORECAST'
        """
        self.db = db
        self.column_mapping = column_mapping
        self.sheet_type = sheet_type

        # Determine table names from sheet type
        if sheet_type == "ACTUALS":
            self.stg_table   = "CES_SAVINGS_STG_ACTUALS"
            self.fact_table  = "CES_SAVINGS_FACT_ACTUALS"
            self.period_col  = "REPORTING_PERIOD"
        else:
            self.stg_table   = "CES_SAVINGS_STG_FORECAST"
            self.fact_table  = "CES_SAVINGS_FACT_FORECAST"
            self.period_col  = "FORECAST_PERIOD"

        # FACT column list (from mapping + metadata)
        self.fact_columns = [
            m["FACT_COLUMN_NAME"] for m in column_mapping
            if m["FACT_COLUMN_NAME"]
        ]

    # --------------------------------------------------------
    # STG LOAD
    # --------------------------------------------------------
    def load_to_stg(self, df: pd.DataFrame, batch_id: int) -> int:
        """
        Load raw data to STG table.
        STG columns are all VARCHAR2 so cast everything to string.
        Returns rows loaded.
        """
        stg_df = df.copy()

        # Build STG column list from mapping
        stg_cols = [
            m["STG_COLUMN_NAME"] for m in self.column_mapping
            if m["STG_COLUMN_NAME"] in stg_df.columns
        ]

        # Add metadata columns present in STG
        meta_cols = ["SOURCE_FILE_NAME", "BATCH_ID"]
        load_cols = stg_cols + [c for c in meta_cols if c in stg_df.columns]

        # Convert all to string for STG (VARCHAR2)
        records = []
        for _, row in stg_df.iterrows():
            record = {}
            for col in load_cols:
                val = row.get(col)
                record[col] = str(val) if val is not None else None
            records.append(record)

        # Build insert SQL
        col_list = ", ".join(load_cols)
        bind_list = ", ".join(f":{c}" for c in load_cols)
        sql = f"INSERT INTO {self.stg_table} ({col_list}) VALUES ({bind_list})"

        rows = self.db.execute_many(sql, records)
        logger.info(f"Loaded {rows} rows to {self.stg_table}")
        return rows

    # --------------------------------------------------------
    # DIMENSION RESOLUTION
    # --------------------------------------------------------
    def ensure_vendor(self, row: dict) -> int:
        """
        Ensure DIM_VENDOR row exists for this vendor subprogram key.
        Insert if new. Returns VENDOR_SUBPROGRAM_SK.
        """
        vendor_key = row.get("VENDOR_SUBPROGRAM_KEY")

        # Look up existing
        existing = self.db.fetch_one(
            """
            SELECT VENDOR_SUBPROGRAM_SK
            FROM   CES_SAVINGS_DIM_VENDOR
            WHERE  VENDOR_SUBPROGRAM_KEY = :key
            AND    IS_CURRENT = 'Y'
            """,
            {"key": vendor_key}
        )

        if existing:
            return existing["VENDOR_SUBPROGRAM_SK"]

        # Insert new vendor
        with self.db.get_cursor() as cursor:
            sk_var = cursor.var(int)
            cursor.execute(
                """
                INSERT INTO CES_SAVINGS_DIM_VENDOR
                (VENDOR_SUBPROGRAM_KEY, SECTOR, PROGRAM, SUBPROGRAM,
                 TRIENNIUM, EFFECTIVE_DATE, IS_CURRENT)
                VALUES
                (:key, :sector, :program, :subprogram,
                 :triennium, SYSDATE, 'Y')
                RETURNING VENDOR_SUBPROGRAM_SK INTO :sk
                """,
                {
                    "key":        vendor_key,
                    "sector":     row.get("SECTOR"),
                    "program":    row.get("PROGRAM"),
                    "subprogram": row.get("SUBPROGRAM"),
                    "triennium":  row.get("TRIENNIUM"),
                    "sk":         sk_var
                }
            )
            vendor_sk = sk_var.getvalue()[0]

        logger.debug(f"Inserted new vendor: {vendor_key} -> SK={vendor_sk}")
        return vendor_sk

    def ensure_period(self, file_info: dict) -> int:
        """
        Ensure DIM_PERIOD row exists. Insert if new.
        Returns PERIOD_SK (YYYYMMDD format).
        """
        period_sk = file_info["period_sk"]
        data_date = file_info["data_date"]

        existing = self.db.fetch_one(
            "SELECT PERIOD_SK FROM CES_SAVINGS_DIM_PERIOD WHERE PERIOD_SK = :sk",
            {"sk": period_sk}
        )

        if existing:
            return period_sk

        # Derive period attributes
        self.db.execute(
            """
            INSERT INTO CES_SAVINGS_DIM_PERIOD
            (PERIOD_SK, REPORTING_PERIOD, PERIOD_YEAR, PERIOD_MONTH,
             PERIOD_MONTH_NAME, PERIOD_QUARTER, FISCAL_YEAR, FISCAL_QUARTER)
            VALUES
            (:period_sk, :reporting_period, :year, :month,
             :month_name, :quarter, :fiscal_year, :fiscal_quarter)
            """,
            {
                "period_sk":        period_sk,
                "reporting_period": file_info["reporting_period"],
                "year":             data_date.year,
                "month":            data_date.month,
                "month_name":       data_date.strftime("%B"),
                "quarter":          (data_date.month - 1) // 3 + 1,
                "fiscal_year":      f"FY{data_date.year}",
                "fiscal_quarter":   f"Q{(data_date.month - 1) // 3 + 1}"
            }
        )
        logger.debug(f"Inserted new period: {period_sk}")
        return period_sk

    # --------------------------------------------------------
    # RESUBMISSION HANDLING
    # --------------------------------------------------------
    def check_resubmission(self, vendor_sk: int, period_sk: int) -> Optional[int]:
        """
        Check if data already exists for this vendor + period.
        Returns max VERSION_NUMBER if exists, else None.
        """
        result = self.db.fetch_one(
            f"""
            SELECT MAX(VERSION_NUMBER) AS MAX_VERSION
            FROM   {self.fact_table}
            WHERE  VENDOR_SUBPROGRAM_SK = :vendor_sk
            AND    PERIOD_SK            = :period_sk
            AND    IS_CURRENT_VERSION   = 'Y'
            """,
            {"vendor_sk": vendor_sk, "period_sk": period_sk}
        )
        return result["MAX_VERSION"] if result and result["MAX_VERSION"] else None

    def expire_old_version(self, vendor_sk: int, period_sk: int) -> None:
        """Mark existing current version as superseded."""
        self.db.execute(
            f"""
            UPDATE {self.fact_table}
            SET    IS_CURRENT_VERSION = 'N',
                   UPDATED_DATE       = SYSTIMESTAMP
            WHERE  VENDOR_SUBPROGRAM_SK = :vendor_sk
            AND    PERIOD_SK            = :period_sk
            AND    IS_CURRENT_VERSION   = 'Y'
            """,
            {"vendor_sk": vendor_sk, "period_sk": period_sk}
        )
        logger.info(
            f"Expired old version: vendor_sk={vendor_sk} period_sk={period_sk}"
        )

    # --------------------------------------------------------
    # FACT LOAD
    # --------------------------------------------------------
    def load_to_fact(
        self,
        df: pd.DataFrame,
        file_info: dict,
        batch_id: int
    ) -> tuple:
        """
        Load transformed data to FACT table.
        Handles dimension lookups and resubmission versioning.

        Returns (rows_loaded, is_resubmission_flag).
        """
        period_sk = self.ensure_period(file_info)
        is_resubmission = False
        records = []

        for _, row in df.iterrows():
            row_dict = row.to_dict()

            # Resolve vendor SK
            vendor_sk = self.ensure_vendor(row_dict)

            # Check resubmission (once per vendor+period)
            existing_version = self.check_resubmission(vendor_sk, period_sk)
            version_number = 1
            if existing_version:
                is_resubmission = True
                self.expire_old_version(vendor_sk, period_sk)
                version_number = existing_version + 1

            # Build FACT record
            record = {
                "VENDOR_SUBPROGRAM_SK": vendor_sk,
                "PERIOD_SK":            period_sk,
                "DATA_DATE":            file_info["data_date"],
                "SOURCE_FILE_NAME":     file_info["file_name"],
                "BATCH_ID":             batch_id,
                "VERSION_NUMBER":       version_number,
                "IS_CURRENT_VERSION":   "Y",
            }

            # Period natural key column (REPORTING_PERIOD or FORECAST_PERIOD)
            record[self.period_col] = file_info["reporting_period"]

            # Add all mapped FACT columns from the row
            for m in self.column_mapping:
                fact_col = m["FACT_COLUMN_NAME"]
                stg_col  = m["STG_COLUMN_NAME"]
                if fact_col and stg_col in row_dict:
                    record[fact_col] = row_dict[stg_col]

            records.append(record)

        if not records:
            return 0, is_resubmission

        # Build insert SQL from first record's keys
        cols = list(records[0].keys())
        col_list = ", ".join(cols)
        bind_list = ", ".join(f":{c}" for c in cols)
        sql = f"INSERT INTO {self.fact_table} ({col_list}) VALUES ({bind_list})"

        rows = self.db.execute_many(sql, records)
        logger.info(
            f"Loaded {rows} rows to {self.fact_table} "
            f"(resubmission={is_resubmission})"
        )
        return rows, is_resubmission
