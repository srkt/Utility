# ============================================================
# CES Savings ETL - Transformer
# Cleans and type-casts data from STG format to FACT format
# Preserves NULL distinct from 0 per business rule
# ============================================================

import logging
import pandas as pd
from datetime import date

logger = logging.getLogger("ces_etl.transformer")


class DataTransformer:
    """
    Transforms validated STG data into FACT-ready format.

    - Casts numeric strings to proper numbers (commas stripped)
    - Preserves NULL as None (NULL != 0)
    - Adds metadata: period_sk, data_date, vendor key, file name, batch id
    - Leaves dimension columns as strings
    """

    def __init__(self, column_mapping: list):
        self.column_mapping = column_mapping
        self.numeric_cols = {
            m["STG_COLUMN_NAME"]: m["DATA_TYPE"]
            for m in column_mapping
            if m["DATA_TYPE"] in ("NUMBER_2", "NUMBER_4", "NUMBER_INT")
        }

    def transform(
        self,
        df: pd.DataFrame,
        file_info: dict,
        batch_id: int
    ) -> pd.DataFrame:
        """
        Transform DataFrame for FACT loading.

        Args:
            df: validated DataFrame with STG column names
            file_info: dict with period_sk, data_date, vendor_key, file_name
            batch_id: current batch id

        Returns:
            Transformed DataFrame ready for FACT insert
        """
        df = df.copy()

        # Cast numeric columns, preserving NULL
        for col, dtype in self.numeric_cols.items():
            if col in df.columns:
                df[col] = df[col].apply(lambda v: self._cast_number(v, dtype))

        # Strip whitespace from dimension/text columns
        text_cols = [c for c in df.columns if c not in self.numeric_cols]
        for col in text_cols:
            df[col] = df[col].apply(
                lambda v: str(v).strip() if v is not None and str(v).strip() != "" else None
            )

        # Add metadata columns derived from filename
        df["PERIOD_SK"]             = file_info["period_sk"]
        df["DATA_DATE"]             = file_info["data_date"]
        df["SOURCE_FILE_NAME"]      = file_info["file_name"]
        df["BATCH_ID"]              = batch_id

        # Resolve VENDOR_SUBPROGRAM_SK is done in loader (needs DIM lookup)

        logger.info(f"Transformed {len(df)} rows for FACT loading")
        return df

    @staticmethod
    def _cast_number(value, dtype: str):
        """
        Cast a value to number, preserving NULL as None.

        NULL/blank -> None (preserved, NOT converted to 0)
        '1,234.56' -> 1234.56
        NUMBER_INT -> rounded to integer
        """
        if value is None or str(value).strip() == "":
            return None  # Preserve NULL - business rule: NULL != 0

        try:
            cleaned = str(value).replace(",", "").replace("$", "").strip()
            if cleaned.upper() in ("N/A", "NA", "NULL", "-"):
                return None
            num = float(cleaned)
            if dtype == "NUMBER_INT":
                return int(round(num))
            return num
        except (ValueError, TypeError):
            # Should not happen after validation but guard anyway
            logger.warning(f"Could not cast '{value}' to {dtype}, setting None")
            return None
