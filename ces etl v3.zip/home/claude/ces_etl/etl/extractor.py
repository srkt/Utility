# ============================================================
# CES Savings ETL - Extractor
# Reads vendor Excel files with 3-row merged headers
# Maps Excel headers to Oracle column names via column map
# Stops loading at blank VENDOR_SUBPROGRAM_KEY
# ============================================================

import re
import logging
import pandas as pd
from pathlib import Path
from typing import Optional
import yaml
import openpyxl
from rapidfuzz import fuzz

logger = logging.getLogger("ces_etl.extractor")

# Load config
config_path = Path(__file__).parent.parent / "config" / "pipeline_config.yaml"
with open(config_path) as f:
    _config = yaml.safe_load(f)

EXCEL_CONFIG = _config["excel"]


def clean_header(value) -> str:
    """
    Clean Excel header cell value to standard format.
    Rules:
    - Convert to string
    - Strip whitespace and line breaks
    - Remove special characters (keep alphanumeric and spaces)
    - Replace spaces with underscore
    - Remove consecutive underscores
    - Uppercase

    Examples:
    'Annual Electric Savings - kWh' -> 'ANNUAL_ELECTRIC_SAVINGS_KWH'
    'Res LMI or OBC'               -> 'RES_LMI_OR_OBC'
    'Net Realized Site\\nAnnual'   -> 'NET_REALIZED_SITE_ANNUAL'
    None                           -> ''
    """
    if value is None or str(value).strip() == "" or str(value).startswith("Unnamed"):
        return ""

    # Convert to string and clean
    cleaned = str(value)

    # Remove line breaks from merged cells
    cleaned = cleaned.replace("\n", " ").replace("\r", " ")

    # Strip whitespace
    cleaned = cleaned.strip()

    # Remove leading number prefix e.g. "1) " "2. " "3- " "1 "
    cleaned = re.sub(r'^\d+[\)\.\-\s]+\s*', '', cleaned)

    # Remove special characters, keep alphanumeric and spaces
    cleaned = re.sub(r"[^a-zA-Z0-9\s]", "", cleaned)

    # Replace spaces with underscore
    cleaned = cleaned.strip().replace(" ", "_")

    # Remove consecutive underscores
    cleaned = re.sub(r"_+", "_", cleaned)

    # Remove leading/trailing underscores
    cleaned = cleaned.strip("_")

    return cleaned.upper()


class ExcelExtractor:
    """
    Extracts data from vendor Excel files.

    Mapping strategy (Option C - Index + Fuzzy + Row1/2 confidence):
    - Primary   : Column index from EXCEL_COL_POSITION (60 points)
    - Validation: Row 3 fuzzy match against expected header (30 points)
    - Confidence: Row 1 + Row 2 match against expected (10 points)

    Score thresholds:
    >= 80 : LOAD          ✓
    60-79 : LOAD + WARN   ⚠  (index matched but header differs)
    < 60  : SKIP + ERROR  ✗  (index not in mapping)

    Column order guaranteed by stakeholder agreement.
    Row 1/2 used for additional confidence only (unreliable due to merges).
    Stops at blank VENDOR_SUBPROGRAM_KEY.
    """

    def __init__(self, column_mapping: list, sheet_config: dict):
        """
        Args:
            column_mapping: List of mapping dicts from CES_SAVINGS_COLUMN_MAP
            sheet_config: Sheet config from pipeline_config.yaml
        """
        self.column_mapping = column_mapping
        self.sheet_config   = sheet_config
        self.header_row     = sheet_config["header_row"]     # Row 3 (1-indexed)
        self.row1_idx       = sheet_config["row1_header_row"]  # Row 1
        self.row2_idx       = sheet_config["row2_header_row"]  # Row 2
        self.data_start_row = sheet_config["data_start_row"]   # Row 4
        self.sheet_name     = sheet_config["sheet_name"]

        # Build lookup dict from column mapping
        # Key: (clean_row1, clean_row2, clean_row3)
        # Value: stg_column_name
        self._mapping_lookup = self._build_mapping_lookup()

        # Find stop column name
        self._stop_column = next(
            (m["STG_COLUMN_NAME"] for m in column_mapping if m["IS_STOP_COLUMN"] == "Y"),
            "VENDOR_SUBPROGRAM_KEY"
        )

    def _build_mapping_lookup(self) -> dict:
        """
        Build index-based lookup dict from column mapping.

        Key   : EXCEL_COL_POSITION (0-based integer index)
        Value : dict with oracle col + expected headers for scoring

        Index is the primary key - column order is guaranteed
        by stakeholder agreement.
        """
        lookup = {}
        for mapping in self.column_mapping:
            idx = mapping.get("EXCEL_COL_POSITION")
            if idx is None:
                continue
            # Convert to 0-based index (mapping table stores 1-based)
            idx = int(idx) - 1
            lookup[idx] = {
                "stg_column":    mapping["STG_COLUMN_NAME"],
                "row3_expected": clean_header(
                    mapping.get("EXCEL_ROW3_HEADER", "")
                ),
                "row1_expected": clean_header(
                    mapping.get("EXCEL_ROW1_EXPECTED",
                    mapping.get("EXCEL_ROW1_HEADER", ""))
                ),
                "row2_expected": clean_header(
                    mapping.get("EXCEL_ROW2_EXPECTED",
                    mapping.get("EXCEL_ROW2_HEADER", ""))
                ),
                "fuzzy_threshold": float(
                    mapping.get("FUZZY_THRESHOLD", 75)
                )
            }

        logger.debug(f"Built index mapping with {len(lookup)} entries")
        return lookup

    def extract(self, file_path: Path) -> tuple:
        """
        Extract data from Excel file.

        Returns:
            (DataFrame with Oracle column names, int row_count_source)

        DataFrame contains only mapped columns.
        Rows stop at blank VENDOR_SUBPROGRAM_KEY.
        """
        logger.info(f"Extracting: {file_path.name} sheet='{self.sheet_name}'")

        # Read raw Excel without parsing headers
        wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)

        if self.sheet_name not in wb.sheetnames:
            raise ValueError(
                f"Sheet '{self.sheet_name}' not found in {file_path.name}. "
                f"Available sheets: {wb.sheetnames}"
            )

        ws = wb[self.sheet_name]

        # Read header rows
        all_rows = list(ws.values)
        row1_values = all_rows[self.row1_idx - 1]  # Convert to 0-indexed
        row2_values = all_rows[self.row2_idx - 1]
        row3_values = all_rows[self.header_row - 1]

        # Build column mapping for this specific file
        # propagate merged cell values (merged cells appear as None after first cell)
        row1_propagated = self._propagate_merged(row1_values)
        row2_propagated = self._propagate_merged(row2_values)

        col_map = self._map_columns(
            row1_propagated, row2_propagated, row3_values
        )

        if not col_map:
            raise ValueError(
                f"No columns could be mapped in {file_path.name}. "
                f"Check column_mapping table and header row config."
            )

        logger.info(f"Mapped {len(col_map)} columns from {len(row3_values)} Excel columns")

        # Read data rows
        data_rows = all_rows[self.data_start_row - 1:]  # Convert to 0-indexed
        wb.close()

        # Build DataFrame from mapped columns only
        records = []
        row_count_source = 0

        for excel_row_num, row in enumerate(data_rows, start=self.data_start_row):
            row_count_source += 1

            # Get stop column value
            stop_col_idx = next(
                (idx for idx, col_name in col_map.items() if col_name == self._stop_column),
                None
            )

            if stop_col_idx is not None:
                stop_value = row[stop_col_idx] if stop_col_idx < len(row) else None
                # Stop condition: VENDOR_SUBPROGRAM_KEY is null or blank
                if stop_value is None or str(stop_value).strip() == "":
                    logger.debug(
                        f"Stop condition reached at row {excel_row_num}: "
                        f"{self._stop_column} is blank"
                    )
                    break

            # Build record with only mapped columns
            record = {}
            for col_idx, oracle_col in col_map.items():
                value = row[col_idx] if col_idx < len(row) else None
                record[oracle_col] = value

            records.append(record)

        df = pd.DataFrame(records)
        logger.info(
            f"Extracted {len(df)} data rows "
            f"({row_count_source} total rows scanned) "
            f"from {file_path.name}"
        )

        return df, row_count_source

    def _propagate_merged(self, row_values: tuple) -> list:
        """
        Propagate merged cell values.
        In openpyxl, merged cells beyond the first return None.
        Forward fill non-None values.

        Example:
        [None, None, 'Electric', None, None, 'Natural Gas', None]
        -> ['', '', 'Electric', 'Electric', 'Electric', 'Natural Gas', 'Natural Gas']
        """
        result = []
        last_value = ""
        for val in row_values:
            if val is not None and str(val).strip() != "":
                last_value = str(val).strip()
            result.append(last_value)
        return result

    def _map_columns(
        self,
        row1: list,
        row2: list,
        row3: tuple
    ) -> dict:
        """
        Map Excel columns to Oracle column names using scoring.

        Score breakdown (total possible = 100):
          Index match  (EXCEL_COL_POSITION) = 60 pts  PRIMARY
          Row 3 fuzzy match                 = 30 pts  VALIDATION
          Row 1 + Row 2 match               = 10 pts  CONFIDENCE BONUS
                                              (5 pts each)

        Thresholds:
          >= 80 : LOAD          ✓
          60-79 : LOAD + WARN   ⚠  index matched, header differs
          <  60 : SKIP + ERROR  ✗  index not in mapping

        Row 1/2 used as bonus confidence only.
        Unreliable for primary lookup due to merged cells.
        Column order guaranteed by stakeholder agreement.
        """
        col_map = {}
        warned  = []
        skipped = []

        for col_idx, row3_val in enumerate(row3):
            score = 0

            # ------------------------------------------------
            # PRIMARY: Index lookup = 60 points
            # ------------------------------------------------
            mapping = self._mapping_lookup.get(col_idx)
            if mapping is None:
                continue  # Not a column we care about

            score          += 60
            oracle_col      = mapping["stg_column"]
            row3_expected   = mapping["row3_expected"]
            row1_expected   = mapping["row1_expected"]
            row2_expected   = mapping["row2_expected"]
            fuzzy_threshold = mapping["fuzzy_threshold"]
            row3_warnings   = []

            # ------------------------------------------------
            # VALIDATION: Row 3 fuzzy = 30 points
            # ------------------------------------------------
            r3_actual = clean_header(row3_val)
            if row3_expected and r3_actual:
                r3_score = fuzz.token_sort_ratio(r3_actual, row3_expected)
                if r3_score >= fuzzy_threshold:
                    score += 30
                else:
                    row3_warnings.append(
                        f"row3 col={col_idx} "
                        f"actual='{r3_actual}' "
                        f"expected='{row3_expected}' "
                        f"score={r3_score}%"
                    )
            else:
                # No expected row3 or blank actual - give partial credit
                score += 15

            # ------------------------------------------------
            # CONFIDENCE BONUS: Row 1 = 5 points
            # ------------------------------------------------
            r1_actual = clean_header(
                row1[col_idx] if col_idx < len(row1) else ""
            )
            if row1_expected:
                r1_score = fuzz.token_sort_ratio(r1_actual, row1_expected)
                if r1_score >= 70:
                    score += 5
            else:
                score += 5  # No row1 expected = full bonus

            # ------------------------------------------------
            # CONFIDENCE BONUS: Row 2 = 5 points
            # ------------------------------------------------
            r2_actual = clean_header(
                row2[col_idx] if col_idx < len(row2) else ""
            )
            if row2_expected:
                r2_score = fuzz.token_sort_ratio(r2_actual, row2_expected)
                if r2_score >= 70:
                    score += 5
            else:
                score += 5  # No row2 expected = full bonus

            # ------------------------------------------------
            # DECISION
            # ------------------------------------------------
            if score >= 80:
                col_map[col_idx] = oracle_col
                logger.debug(
                    f"Mapped col {col_idx} score={score} -> {oracle_col}"
                )

            elif score >= 60:
                # Index matched but header validation warnings
                col_map[col_idx] = oracle_col
                msg = (
                    f"col={col_idx} score={score} "
                    f"oracle={oracle_col} {row3_warnings}"
                )
                warned.append(msg)
                logger.warning(f"Loaded with warnings: {msg}")

            else:
                # Should not happen with guaranteed column order
                # but guard against edge cases
                msg = (
                    f"col={col_idx} score={score} "
                    f"oracle={oracle_col} {row3_warnings}"
                )
                skipped.append(msg)
                logger.error(f"Skipped low score: {msg}")

        if warned:
            logger.warning(f"{len(warned)} columns loaded with warnings")
        if skipped:
            logger.error(f"{len(skipped)} columns skipped - check mapping")

        return col_map

    def validate_template_version(self, file_path: Path) -> Optional[str]:
        """
        Check template version in file title cell.
        Returns version string found or None if not found.
        Logs warning if version differs from expected.
        """
        expected = EXCEL_CONFIG.get("expected_template_version")
        if not expected:
            return None

        wb = openpyxl.load_workbook(file_path, read_only=True)
        ws = wb[self.sheet_name]

        # Template version is typically in first few rows
        version_found = None
        for row in ws.iter_rows(min_row=1, max_row=5, values_only=True):
            for cell in row:
                if cell and "Ver" in str(cell):
                    # Extract version number e.g. "Ver 05.12.26"
                    match = re.search(r"Ver\s+([\d.]+)", str(cell))
                    if match:
                        version_found = match.group(1)
                        break
            if version_found:
                break

        wb.close()

        if version_found and version_found != expected:
            logger.warning(
                f"Template version mismatch in {file_path.name}: "
                f"found={version_found} expected={expected}. "
                f"Proceeding with load but verify column mapping."
            )
        elif not version_found:
            logger.debug(f"Could not find template version in {file_path.name}")

        return version_found
