"""
Run real (non-mock) tests only.
Shows ONLY failed tests.
Usage: python run_real_tests.py
"""
import subprocess
import sys

result = subprocess.run(
    [
        sys.executable, "-m", "pytest",
        "tests/",
        "-v",
        "-k", "Real",
        "--ignore=tests/test_main.py",
        "--tb=short",      # short traceback on failure
        "--no-header",     # cleaner output
        "-q"               # quiet - hides passed tests
    ],
    cwd="."
)

sys.exit(result.returncode)
