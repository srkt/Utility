# ============================================================
# CES Savings ETL - Email Notifier
# Sends notifications on batch completion/failure
# ============================================================

import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
import yaml

logger = logging.getLogger("ces_etl.notifier")

config_path = Path(__file__).parent.parent / "config" / "pipeline_config.yaml"
with open(config_path) as f:
    _config = yaml.safe_load(f)

NOTIF_CONFIG = _config.get("notifications", {})


class Notifier:
    """Sends email notifications about ETL pipeline events."""

    def __init__(self):
        self.enabled = NOTIF_CONFIG.get("enabled", False)
        self.notify_on = NOTIF_CONFIG.get("notify_on", [])

    def send(self, event: str, subject: str, body: str) -> None:
        """
        Send notification email if event is in notify_on list.

        Args:
            event: event type e.g. BATCH_SUCCESS, BATCH_FAILED
            subject: email subject
            body: email body (plain text)
        """
        if not self.enabled:
            logger.debug("Notifications disabled, skipping")
            return

        if event not in self.notify_on:
            logger.debug(f"Event {event} not in notify_on list, skipping")
            return

        try:
            msg = MIMEMultipart()
            msg["From"]    = NOTIF_CONFIG["from_address"]
            msg["To"]      = ", ".join(NOTIF_CONFIG["to_addresses"])
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))

            with smtplib.SMTP(
                NOTIF_CONFIG["smtp_host"],
                NOTIF_CONFIG["smtp_port"]
            ) as server:
                server.starttls()
                server.login(
                    NOTIF_CONFIG["smtp_user"],
                    NOTIF_CONFIG["smtp_password"]
                )
                server.send_message(msg)

            logger.info(f"Notification sent: {event} -> {NOTIF_CONFIG['to_addresses']}")

        except Exception as e:
            # Never let notification failure break the pipeline
            logger.error(f"Failed to send notification: {e}")

    def notify_batch_complete(self, batch_id: int, stats: dict) -> None:
        """Send batch completion summary."""
        status = stats.get("status", "UNKNOWN")
        event = f"BATCH_{status}"

        subject = f"[CES ETL] Batch {batch_id} {status}"
        body = f"""
CES Savings ETL Pipeline Report
================================
Batch ID:          {batch_id}
Status:            {status}

Files Expected:    {stats.get('files_expected', 0)}
Files Succeeded:   {stats.get('files_succeeded', 0)}
Files Failed:      {stats.get('files_failed', 0)}
Files Quarantined: {stats.get('files_quarantined', 0)}

Rows Loaded:       {stats.get('rows_loaded', 0)}
Rows Failed:       {stats.get('rows_failed', 0)}

{stats.get('error_message', '')}
""".strip()

        self.send(event, subject, body)
