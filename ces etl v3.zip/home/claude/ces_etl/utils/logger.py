# ============================================================
# CES Savings ETL - Logging Utility
# Logs to both file and Oracle audit tables
# ============================================================

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional
import yaml
import colorlog

# Load config
config_path = Path(__file__).parent.parent / "config" / "pipeline_config.yaml"
with open(config_path) as f:
    _config = yaml.safe_load(f)

LOG_CONFIG = _config.get("logging", {})


def setup_logger(name: str = "ces_etl") -> logging.Logger:
    """
    Set up colored console logger and file logger.
    Call once at pipeline startup.
    """
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, LOG_CONFIG.get("level", "INFO")))

    # Avoid duplicate handlers
    if logger.handlers:
        return logger

    # Console handler with color
    console_handler = colorlog.StreamHandler(sys.stdout)
    console_handler.setFormatter(colorlog.ColoredFormatter(
        "%(log_color)s%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        log_colors={
            "DEBUG":    "cyan",
            "INFO":     "green",
            "WARNING":  "yellow",
            "ERROR":    "red",
            "CRITICAL": "red,bg_white",
        }
    ))
    logger.addHandler(console_handler)

    # File handler
    if LOG_CONFIG.get("log_to_file", True):
        log_dir = Path(LOG_CONFIG.get("log_path", "/var/log/ces_etl"))
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / f"ces_etl_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        ))
        logger.addHandler(file_handler)
        logger.info(f"Logging to file: {log_file}")

    return logger


class AuditLogger:
    """
    Logs ETL events to Oracle audit tables.
    Three levels: Batch, File, Row
    """

    def __init__(self, db):
        self.db = db
        self.logger = logging.getLogger("ces_etl.audit")

    # --------------------------------------------------------
    # BATCH LEVEL LOGGING
    # --------------------------------------------------------
    def start_batch(self, jenkins_job: str = None, build_number: str = None) -> int:
        """
        Create batch log record at pipeline start.
        Returns BATCH_ID for use throughout pipeline run.
        """
        sql = """
            INSERT INTO CES_SAVINGS_ETL_BATCH_LOG
            (BATCH_START_DT, STATUS, TRIGGERED_BY,
             JENKINS_JOB_NAME, JENKINS_BUILD_NUMBER)
            VALUES
            (SYSTIMESTAMP, 'RUNNING', :triggered_by,
             :job_name, :build_number)
            RETURNING BATCH_ID INTO :batch_id
        """
        with self.db.get_cursor() as cursor:
            batch_id_var = cursor.var(int)
            cursor.execute(sql, {
                "triggered_by":  jenkins_job or "MANUAL",
                "job_name":      jenkins_job,
                "build_number":  build_number,
                "batch_id":      batch_id_var
            })
            batch_id = batch_id_var.getvalue()[0]

        self.logger.info(f"Batch started: BATCH_ID={batch_id}")
        return batch_id

    def complete_batch(
        self,
        batch_id: int,
        status: str,
        files_expected: int = 0,
        files_succeeded: int = 0,
        files_failed: int = 0,
        files_skipped: int = 0,
        files_quarantined: int = 0,
        rows_loaded: int = 0,
        rows_failed: int = 0,
        error_message: str = None
    ) -> None:
        """Update batch log record at pipeline completion"""
        sql = """
            UPDATE CES_SAVINGS_ETL_BATCH_LOG
            SET    BATCH_END_DT          = SYSTIMESTAMP,
                   STATUS                = :status,
                   TOTAL_FILES_EXPECTED  = :files_expected,
                   FILES_SUCCEEDED       = :files_succeeded,
                   FILES_FAILED          = :files_failed,
                   FILES_SKIPPED         = :files_skipped,
                   FILES_QUARANTINED     = :files_quarantined,
                   TOTAL_ROWS_LOADED     = :rows_loaded,
                   TOTAL_ROWS_FAILED     = :rows_failed,
                   ERROR_MESSAGE         = :error_message
            WHERE  BATCH_ID              = :batch_id
        """
        self.db.execute(sql, {
            "batch_id":         batch_id,
            "status":           status,
            "files_expected":   files_expected,
            "files_succeeded":  files_succeeded,
            "files_failed":     files_failed,
            "files_skipped":    files_skipped,
            "files_quarantined":files_quarantined,
            "rows_loaded":      rows_loaded,
            "rows_failed":      rows_failed,
            "error_message":    error_message
        })
        self.logger.info(
            f"Batch {batch_id} completed: STATUS={status} "
            f"FILES={files_succeeded}/{files_expected} "
            f"ROWS={rows_loaded}"
        )

    # --------------------------------------------------------
    # FILE LEVEL LOGGING
    # --------------------------------------------------------
    def start_file(
        self,
        batch_id: int,
        file_name: str,
        file_type: str,
        vendor_key: str,
        reporting_period: str,
        file_path_source: str
    ) -> int:
        """
        Create file log record when file processing starts.
        Returns FILE_LOG_ID.
        """
        sql = """
            INSERT INTO CES_SAVINGS_ETL_FILE_LOG
            (BATCH_ID, FILE_NAME, FILE_TYPE, VENDOR_KEY,
             REPORTING_PERIOD, FILE_RECEIVED_DT, STATUS,
             FILE_PATH_SOURCE)
            VALUES
            (:batch_id, :file_name, :file_type, :vendor_key,
             :reporting_period, SYSTIMESTAMP, 'PROCESSING',
             :file_path_source)
            RETURNING FILE_LOG_ID INTO :file_log_id
        """
        with self.db.get_cursor() as cursor:
            file_log_id_var = cursor.var(int)
            cursor.execute(sql, {
                "batch_id":         batch_id,
                "file_name":        file_name,
                "file_type":        file_type,
                "vendor_key":       vendor_key,
                "reporting_period": reporting_period,
                "file_path_source": file_path_source,
                "file_log_id":      file_log_id_var
            })
            file_log_id = file_log_id_var.getvalue()[0]

        self.logger.info(f"File started: FILE_LOG_ID={file_log_id} FILE={file_name}")
        return file_log_id

    def complete_file(
        self,
        file_log_id: int,
        status: str,
        row_count_source: int = 0,
        row_count_loaded: int = 0,
        row_count_failed: int = 0,
        is_resubmission: str = "N",
        prev_file_log_id: Optional[int] = None,
        file_path_archive: str = None,
        file_path_quarantine: str = None,
        validation_errors: str = None,
        error_message: str = None
    ) -> None:
        """Update file log record at file completion"""
        sql = """
            UPDATE CES_SAVINGS_ETL_FILE_LOG
            SET    FILE_PROCESSED_DT    = SYSTIMESTAMP,
                   STATUS               = :status,
                   ROW_COUNT_SOURCE     = :row_count_source,
                   ROW_COUNT_LOADED     = :row_count_loaded,
                   ROW_COUNT_FAILED     = :row_count_failed,
                   IS_RESUBMISSION      = :is_resubmission,
                   PREV_FILE_LOG_ID     = :prev_file_log_id,
                   FILE_PATH_ARCHIVE    = :file_path_archive,
                   FILE_PATH_QUARANTINE = :file_path_quarantine,
                   VALIDATION_ERRORS    = :validation_errors,
                   ERROR_MESSAGE        = :error_message
            WHERE  FILE_LOG_ID          = :file_log_id
        """
        self.db.execute(sql, {
            "file_log_id":          file_log_id,
            "status":               status,
            "row_count_source":     row_count_source,
            "row_count_loaded":     row_count_loaded,
            "row_count_failed":     row_count_failed,
            "is_resubmission":      is_resubmission,
            "prev_file_log_id":     prev_file_log_id,
            "file_path_archive":    file_path_archive,
            "file_path_quarantine": file_path_quarantine,
            "validation_errors":    validation_errors,
            "error_message":        error_message
        })
        self.logger.info(
            f"File {file_log_id} completed: STATUS={status} "
            f"ROWS={row_count_loaded}/{row_count_source}"
        )

    # --------------------------------------------------------
    # ROW LEVEL LOGGING
    # --------------------------------------------------------
    def log_row_error(
        self,
        file_log_id: int,
        batch_id: int,
        row_number: int,
        column_name: str,
        source_value: str,
        error_type: str,
        error_message: str,
        expected_format: str = None
    ) -> None:
        """Log individual row/cell error"""
        sql = """
            INSERT INTO CES_SAVINGS_ETL_ROW_LOG
            (FILE_LOG_ID, BATCH_ID, ROW_NUMBER, COLUMN_NAME,
             SOURCE_VALUE, EXPECTED_FORMAT, ERROR_TYPE,
             ERROR_MESSAGE, STATUS)
            VALUES
            (:file_log_id, :batch_id, :row_number, :column_name,
             :source_value, :expected_format, :error_type,
             :error_message, 'FAILED')
        """
        self.db.execute(sql, {
            "file_log_id":      file_log_id,
            "batch_id":         batch_id,
            "row_number":       row_number,
            "column_name":      column_name,
            "source_value":     str(source_value)[:4000] if source_value else None,
            "expected_format":  expected_format,
            "error_type":       error_type,
            "error_message":    error_message[:4000] if error_message else None
        })
        self.logger.warning(
            f"Row error: FILE={file_log_id} ROW={row_number} "
            f"COL={column_name} TYPE={error_type} VAL={source_value}"
        )
