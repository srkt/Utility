# ============================================================
# CES Savings ETL - File Manager
# Handles file operations on shared drive
# Scan, validate, move, archive vendor files
# ============================================================

import re
import shutil
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional
import yaml

logger = logging.getLogger("ces_etl.file_manager")

# Load config
config_path = Path(__file__).parent.parent / "config" / "pipeline_config.yaml"
with open(config_path) as f:
    _config = yaml.safe_load(f)

FILE_CONFIG  = _config["file_source"]["shared_drive"]
EXCEL_CONFIG = _config["excel"]


class FileManager:
    """
    Manages vendor file lifecycle on shared drive:
    - Scan landing zone for new files
    - Extract period and vendor from filename
    - Move to archive after successful load
    - Move to quarantine on validation failure
    """

    def __init__(self):
        self.landing_path    = Path(FILE_CONFIG["landing_path"])
        self.archive_path    = Path(FILE_CONFIG["archive_path"])
        self.quarantine_path = Path(FILE_CONFIG["quarantine_path"])
        self.filename_pattern = re.compile(
            EXCEL_CONFIG["filename_pattern"],
            re.IGNORECASE
        )
        self._ensure_directories()

    def _ensure_directories(self) -> None:
        """Create directories if they don't exist"""
        for path in [self.landing_path, self.archive_path, self.quarantine_path]:
            path.mkdir(parents=True, exist_ok=True)

    def scan_landing_zone(self) -> list:
        """
        Scan landing zone for .xlsx files matching filename pattern.
        Returns list of file info dicts sorted by filename.

        Returns:
            [
                {
                    "file_path": Path,
                    "file_name": str,
                    "vendor_key": str,
                    "period_sk": int,       # YYYYMMDD format
                    "data_date": date,
                    "reporting_period": str  # "Apr 2026"
                },
                ...
            ]
        """
        files = []
        for file_path in sorted(self.landing_path.glob("*.xlsx")):
            file_info = self._parse_filename(file_path)
            if file_info:
                files.append(file_info)
            else:
                logger.warning(
                    f"File does not match expected pattern, skipping: {file_path.name}"
                )

        logger.info(f"Found {len(files)} valid files in landing zone")
        return files

    def _parse_filename(self, file_path: Path) -> Optional[dict]:
        """
        Extract period and vendor info from filename.

        Expected pattern: VendorName_YYYY_MM.xlsx
        Example: ICF_Residential_LMI_2026_04.xlsx

        Returns None if filename does not match pattern.
        """
        match = self.filename_pattern.search(file_path.name)
        if not match:
            return None

        year  = int(match.group(1))  # 2026
        month = int(match.group(2))  # 4

        # YYYYMMDD format with day always 01 for monthly grain
        period_sk = int(f"{year}{month:02d}01")

        # Proper date for Power BI
        from datetime import date
        data_date = date(year, month, 1)

        # Human readable period: Apr 2026
        reporting_period = data_date.strftime("%b %Y")

        # Vendor key = filename without date and extension
        # ICF_Residential_LMI_2026_04.xlsx -> ICF_Residential_LMI
        vendor_key = re.sub(
            r'_\d{4}_\d{2}\.xlsx$', '', file_path.name, flags=re.IGNORECASE
        )

        return {
            "file_path":        file_path,
            "file_name":        file_path.name,
            "vendor_key":       vendor_key,
            "period_sk":        period_sk,
            "data_date":        data_date,
            "reporting_period": reporting_period,
            "year":             year,
            "month":            month
        }

    def get_period_sk(self, file_name: str) -> Optional[int]:
        """
        Extract PERIOD_SK from filename.
        Returns YYYYMMDD integer or None if no match.
        """
        file_info = self._parse_filename(Path(file_name))
        return file_info["period_sk"] if file_info else None

    def archive_file(self, file_path: Path) -> Path:
        """
        Move successfully processed file to archive.
        Creates year/month subfolder for organisation.
        Returns new archive path.
        """
        file_info = self._parse_filename(file_path)
        if file_info:
            subfolder = self.archive_path / str(file_info["year"]) / f"{file_info['month']:02d}"
        else:
            subfolder = self.archive_path / "unknown"

        subfolder.mkdir(parents=True, exist_ok=True)

        # Add timestamp to avoid overwrite on resubmission
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        archive_name = f"{file_path.stem}_{timestamp}{file_path.suffix}"
        archive_path = subfolder / archive_name

        shutil.move(str(file_path), str(archive_path))
        logger.info(f"Archived: {file_path.name} -> {archive_path}")
        return archive_path

    def quarantine_file(self, file_path: Path, reason: str = None) -> Path:
        """
        Move failed file to quarantine for investigation.
        Returns new quarantine path.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        quarantine_name = f"{file_path.stem}_{timestamp}_QUARANTINE{file_path.suffix}"
        quarantine_path = self.quarantine_path / quarantine_name

        shutil.move(str(file_path), str(quarantine_path))
        logger.warning(
            f"Quarantined: {file_path.name} -> {quarantine_path}"
            + (f" REASON: {reason}" if reason else "")
        )
        return quarantine_path

    def get_file_size_mb(self, file_path: Path) -> float:
        """Return file size in MB"""
        return file_path.stat().st_size / (1024 * 1024)
