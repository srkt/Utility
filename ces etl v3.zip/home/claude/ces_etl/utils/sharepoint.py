# ============================================================
# CES Savings ETL - SharePoint File Manager
# Downloads vendor files from SharePoint
# Separate from shared drive file_manager.py
# Activate by setting file_source.type = "sharepoint"
# in pipeline_config.yaml
# ============================================================

import logging
from pathlib import Path
from typing import Optional
import yaml
from office365.runtime.auth.user_credential import UserCredential
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.client_context import ClientContext

logger = logging.getLogger("ces_etl.sharepoint")

# Load config
config_path = Path(__file__).parent.parent / "config" / "pipeline_config.yaml"
with open(config_path) as f:
    _config = yaml.safe_load(f)

SP_CONFIG    = _config["file_source"]["sharepoint"]
EXCEL_CONFIG = _config["excel"]


class SharePointFileManager:
    """
    Downloads vendor Excel files from SharePoint.
    Authentication via Client ID/Secret (service principal).

    After download, files are handled by regular FileManager
    from the local download_path.
    """

    def __init__(self):
        self.site_url      = SP_CONFIG["site_url"]
        self.folder_path   = SP_CONFIG["folder_path"]
        self.download_path = Path(SP_CONFIG["download_path"])
        self.archive_path  = Path(SP_CONFIG["archive_path"])
        self.download_path.mkdir(parents=True, exist_ok=True)
        self.archive_path.mkdir(parents=True, exist_ok=True)
        self._ctx = None

    def _get_context(self) -> ClientContext:
        """
        Create SharePoint client context using service principal.
        Reuses existing context if already authenticated.
        """
        if self._ctx is None:
            logger.info(f"Connecting to SharePoint: {self.site_url}")
            credentials = ClientCredential(
                SP_CONFIG["client_id"],
                SP_CONFIG["client_secret"]
            )
            self._ctx = ClientContext(self.site_url).with_credentials(credentials)
            logger.info("SharePoint connection established")
        return self._ctx

    def list_files(self) -> list:
        """
        List all .xlsx files in SharePoint vendor submissions folder.

        Returns:
            [
                {
                    "name": str,
                    "server_relative_url": str,
                    "size": int,
                    "time_last_modified": datetime
                },
                ...
            ]
        """
        ctx = self._get_context()
        folder = ctx.web.get_folder_by_server_relative_url(self.folder_path)
        files = folder.files
        ctx.load(files)
        ctx.execute_query()

        result = []
        for f in files:
            if f.name.lower().endswith(".xlsx"):
                result.append({
                    "name":                 f.name,
                    "server_relative_url":  f.server_relative_url,
                    "size":                 f.length,
                    "time_last_modified":   f.time_last_modified
                })

        logger.info(f"Found {len(result)} xlsx files in SharePoint folder")
        return result

    def download_file(self, server_relative_url: str, file_name: str) -> Path:
        """
        Download single file from SharePoint to local download_path.
        Returns local file path.
        """
        ctx = self._get_context()
        local_path = self.download_path / file_name

        with open(local_path, "wb") as f:
            ctx.web.get_file_by_server_relative_url(
                server_relative_url
            ).download(f).execute_query()

        logger.info(f"Downloaded: {file_name} -> {local_path}")
        return local_path

    def download_all_files(self) -> list:
        """
        Download all vendor files from SharePoint to local download_path.
        Returns list of local file paths.
        """
        files = self.list_files()
        downloaded = []

        for file_info in files:
            try:
                local_path = self.download_file(
                    file_info["server_relative_url"],
                    file_info["name"]
                )
                downloaded.append(local_path)
            except Exception as e:
                logger.error(f"Failed to download {file_info['name']}: {e}")

        logger.info(f"Downloaded {len(downloaded)}/{len(files)} files from SharePoint")
        return downloaded

    def archive_sharepoint_file(
        self,
        server_relative_url: str,
        file_name: str
    ) -> Optional[str]:
        """
        Move processed file to SharePoint archive folder.
        Call after successful ETL load.

        Returns new SharePoint URL or None on failure.
        """
        ctx = self._get_context()
        archive_folder_url = f"{self.folder_path}/Archive"

        try:
            # Ensure archive folder exists
            archive_folder = ctx.web.ensure_folder_path(archive_folder_url)
            ctx.execute_query()

            # Move file
            file = ctx.web.get_file_by_server_relative_url(server_relative_url)
            new_url = f"{archive_folder_url}/{file_name}"
            file.moveto(new_url, 1)  # 1 = overwrite if exists
            ctx.execute_query()

            logger.info(f"Archived on SharePoint: {file_name} -> {archive_folder_url}")
            return new_url

        except Exception as e:
            logger.error(f"Failed to archive SharePoint file {file_name}: {e}")
            return None

    def get_download_path(self) -> Path:
        """Return local download path for use with FileManager"""
        return self.download_path
