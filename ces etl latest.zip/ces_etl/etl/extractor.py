# ============================================================
# CES Savings ETL - Extractor
# Reads vendor Excel files with 3-row merged headers
# Maps Excel headers to Oracle column names via column map
# Stops loading at blank VENDOR_SUBPROGRAM_KEY
# ============================================================

import re
import logging
import pandas as pd
from pathlib import Path
from typing import Optional
import yaml
import openpyxl

logger = logging.getLogger("ces_etl.extractor")

# Load config
config_path = Path(__file__).parent.parent / "config" / "pipeline_config.yaml"
with open(config_path) as f:
    _config = yaml.safe_load(f)

EXCEL_CONFIG = _config["excel"]


def clean_header(value) -> str:
    """
    Clean Excel header cell value to standard format.
    Rules:
    - Convert to string
    - Strip whitespace and line breaks
    - Remove special characters (keep alphanumeric and spaces)
    - Replace spaces with underscore
    - Remove consecutive underscores
    - Uppercase

    Examples:
    'Annual Electric Savings - kWh' -> 'ANNUAL_ELECTRIC_SAVINGS_KWH'
    'Res LMI or OBC'               -> 'RES_LMI_OR_OBC'
    'Net Realized Site\\nAnnual'   -> 'NET_REALIZED_SITE_ANNUAL'
    None                           -> ''
    """
    if value is None or str(value).strip() == "" or str(value).startswith("Unnamed"):
        return ""

    # Convert to string and clean
    cleaned = str(value)

    # Remove line breaks from merged cells
    cleaned = cleaned.replace("\n", " ").replace("\r", " ")

    # Strip whitespace
    cleaned = cleaned.strip()

    # Remove leading number prefix e.g. "1) " "2. " "3- " "1 "
    cleaned = re.sub(r'^\d+[\)\.\-\s]+\s*', '', cleaned)

    # Remove special characters, keep alphanumeric and spaces
    cleaned = re.sub(r"[^a-zA-Z0-9\s]", "", cleaned)

    # Replace spaces with underscore
    cleaned = cleaned.strip().replace(" ", "_")

    # Remove consecutive underscores
    cleaned = re.sub(r"_+", "_", cleaned)

    # Remove leading/trailing underscores
    cleaned = cleaned.strip("_")

    return cleaned.upper()


class ExcelExtractor:
    """
    Extracts data from vendor Excel files.

    Key behaviors:
    - Reads header row at configurable row index
    - Reads rows 1 and 2 for context (energy type, calc method)
    - Builds lookup key: row1 + row2 + row3 header
    - Maps to Oracle column names via column mapping
    - Stops at blank VENDOR_SUBPROGRAM_KEY
    - Ignores unmapped columns (extra data to right)
    """

    def __init__(self, column_mapping: list, sheet_config: dict):
        """
        Args:
            column_mapping: List of mapping dicts from CES_SAVINGS_COLUMN_MAP
            sheet_config: Sheet config from pipeline_config.yaml
        """
        self.column_mapping = column_mapping
        self.sheet_config   = sheet_config
        self.header_row     = sheet_config["header_row"]     # Row 3 (1-indexed)
        self.row1_idx       = sheet_config["row1_header_row"]  # Row 1
        self.row2_idx       = sheet_config["row2_header_row"]  # Row 2
        self.data_start_row = sheet_config["data_start_row"]   # Row 4
        self.sheet_name     = sheet_config["sheet_name"]

        # Build lookup dict from column mapping
        # Key: (clean_row1, clean_row2, clean_row3)
        # Value: stg_column_name
        self._mapping_lookup = self._build_mapping_lookup()

        # Find stop column name
        self._stop_column = next(
            (m["STG_COLUMN_NAME"] for m in column_mapping if m["IS_STOP_COLUMN"] == "Y"),
            "VENDOR_SUBPROGRAM_KEY"
        )

    def _build_mapping_lookup(self) -> dict:
        """
        Build fast lookup dict from column mapping list.
        Key: tuple of (clean_row1, clean_row2, clean_row3)
        Value: stg_column_name
        """
        lookup = {}
        for mapping in self.column_mapping:
            key = (
                clean_header(mapping.get("EXCEL_ROW1_HEADER", "")),
                clean_header(mapping.get("EXCEL_ROW2_HEADER", "")),
                clean_header(mapping.get("EXCEL_ROW3_HEADER", ""))
            )
            lookup[key] = mapping["STG_COLUMN_NAME"]

        logger.debug(f"Built mapping lookup with {len(lookup)} entries")
        return lookup

    def extract(self, file_path: Path) -> tuple:
        """
        Extract data from Excel file.

        Returns:
            (DataFrame with Oracle column names, int row_count_source)

        DataFrame contains only mapped columns.
        Rows stop at blank VENDOR_SUBPROGRAM_KEY.
        """
        logger.info(f"Extracting: {file_path.name} sheet='{self.sheet_name}'")

        # Read raw Excel without parsing headers
        wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)

        if self.sheet_name not in wb.sheetnames:
            raise ValueError(
                f"Sheet '{self.sheet_name}' not found in {file_path.name}. "
                f"Available sheets: {wb.sheetnames}"
            )

        ws = wb[self.sheet_name]

        # Read header rows
        all_rows = list(ws.values)
        row1_values = all_rows[self.row1_idx - 1]  # Convert to 0-indexed
        row2_values = all_rows[self.row2_idx - 1]
        row3_values = all_rows[self.header_row - 1]

        # Build column mapping for this specific file
        # propagate merged cell values (merged cells appear as None after first cell)
        row1_propagated = self._propagate_merged(row1_values)
        row2_propagated = self._propagate_merged(row2_values)

        col_map = self._map_columns(
            row1_propagated, row2_propagated, row3_values
        )

        if not col_map:
            raise ValueError(
                f"No columns could be mapped in {file_path.name}. "
                f"Check column_mapping table and header row config."
            )

        logger.info(f"Mapped {len(col_map)} columns from {len(row3_values)} Excel columns")

        # Read data rows
        data_rows = all_rows[self.data_start_row - 1:]  # Convert to 0-indexed
        wb.close()

        # Build DataFrame from mapped columns only
        records = []
        row_count_source = 0

        for excel_row_num, row in enumerate(data_rows, start=self.data_start_row):
            row_count_source += 1

            # Get stop column value
            stop_col_idx = next(
                (idx for idx, col_name in col_map.items() if col_name == self._stop_column),
                None
            )

            if stop_col_idx is not None:
                stop_value = row[stop_col_idx] if stop_col_idx < len(row) else None
                # Stop condition: VENDOR_SUBPROGRAM_KEY is null or blank
                if stop_value is None or str(stop_value).strip() == "":
                    logger.debug(
                        f"Stop condition reached at row {excel_row_num}: "
                        f"{self._stop_column} is blank"
                    )
                    break

            # Build record with only mapped columns
            record = {}
            for col_idx, oracle_col in col_map.items():
                value = row[col_idx] if col_idx < len(row) else None
                record[oracle_col] = value

            records.append(record)

        df = pd.DataFrame(records)
        logger.info(
            f"Extracted {len(df)} data rows "
            f"({row_count_source} total rows scanned) "
            f"from {file_path.name}"
        )

        return df, row_count_source

    def _propagate_merged(self, row_values: tuple) -> list:
        """
        Propagate merged cell values.
        In openpyxl, merged cells beyond the first return None.
        Forward fill non-None values.

        Example:
        [None, None, 'Electric', None, None, 'Natural Gas', None]
        -> ['', '', 'Electric', 'Electric', 'Electric', 'Natural Gas', 'Natural Gas']
        """
        result = []
        last_value = ""
        for val in row_values:
            if val is not None and str(val).strip() != "":
                last_value = str(val).strip()
            result.append(last_value)
        return result

    def _map_columns(
        self,
        row1: list,
        row2: list,
        row3: tuple
    ) -> dict:
        """
        Map Excel column positions to Oracle column names.

        Args:
            row1: Propagated row 1 values (energy type)
            row2: Propagated row 2 values (calc method)
            row3: Row 3 values (actual column headers)

        Returns:
            dict: {excel_col_index: oracle_column_name}
        """
        col_map = {}
        unmapped = []

        for col_idx, row3_val in enumerate(row3):
            # Clean all three header levels
            r1 = clean_header(row1[col_idx] if col_idx < len(row1) else "")
            r2 = clean_header(row2[col_idx] if col_idx < len(row2) else "")
            r3 = clean_header(row3_val)

            if not r3:  # Skip blank headers
                continue

            # Look up in mapping - try full key first
            lookup_key = (r1, r2, r3)
            oracle_col = self._mapping_lookup.get(lookup_key)

            if not oracle_col:
                # Try with empty row1 (dimension/financial columns
                # have no energy type context)
                lookup_key_no_r1 = ("", r2, r3)
                oracle_col = self._mapping_lookup.get(lookup_key_no_r1)

            if not oracle_col:
                # Try with empty row1 and row2 (pure dimension columns)
                lookup_key_dim = ("", "", r3)
                oracle_col = self._mapping_lookup.get(lookup_key_dim)

            if oracle_col:
                col_map[col_idx] = oracle_col
                logger.debug(f"Mapped col {col_idx}: {r1}|{r2}|{r3} -> {oracle_col}")
            else:
                unmapped.append(f"col{col_idx}:{r1}|{r2}|{r3}")

        if unmapped:
            logger.debug(
                f"{len(unmapped)} unmapped columns (ignored): "
                f"{unmapped[:5]}{'...' if len(unmapped) > 5 else ''}"
            )

        return col_map

    def validate_template_version(self, file_path: Path) -> Optional[str]:
        """
        Check template version in file title cell.
        Returns version string found or None if not found.
        Logs warning if version differs from expected.
        """
        expected = EXCEL_CONFIG.get("expected_template_version")
        if not expected:
            return None

        wb = openpyxl.load_workbook(file_path, read_only=True)
        ws = wb[self.sheet_name]

        # Template version is typically in first few rows
        version_found = None
        for row in ws.iter_rows(min_row=1, max_row=5, values_only=True):
            for cell in row:
                if cell and "Ver" in str(cell):
                    # Extract version number e.g. "Ver 05.12.26"
                    match = re.search(r"Ver\s+([\d.]+)", str(cell))
                    if match:
                        version_found = match.group(1)
                        break
            if version_found:
                break

        wb.close()

        if version_found and version_found != expected:
            logger.warning(
                f"Template version mismatch in {file_path.name}: "
                f"found={version_found} expected={expected}. "
                f"Proceeding with load but verify column mapping."
            )
        elif not version_found:
            logger.debug(f"Could not find template version in {file_path.name}")

        return version_found
